AngelSix.com - Luke Malpass
==========================================

- Common engineering parts library toolbox
------------------------------------------

- Place the folder Structural Members into the C:\ drive, and run the macros from the Design Library to create new parts.
- Run macros to create new parts.
- You can modify the location of the files in the macros class modules if you wish to store them somewhere else, and easily expand the list of entries by adding lines to the macros.


You may also find the program SWTools very handy to help easily running these macros. Visit AngelSix.com under the products section to find it.

Enjoy!

PS. Please give all credits to Luke Malpass if re-distributing these macros.

