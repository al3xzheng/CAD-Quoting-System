﻿namespace SWInfoCustomInstallerCS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bInstall = new System.Windows.Forms.Button();
            this.tbFolder = new System.Windows.Forms.TextBox();
            this.cbCreateDesktop = new System.Windows.Forms.CheckBox();
            this.lFolder = new System.Windows.Forms.Label();
            this.lTitle = new System.Windows.Forms.Label();
            this.tbLog = new System.Windows.Forms.TextBox();
            this.lDescription = new System.Windows.Forms.Label();
            this.cbCreateStartMenu = new System.Windows.Forms.CheckBox();
            this.lWarning = new System.Windows.Forms.Label();
            this.bFolderBrowse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bInstall
            // 
            this.bInstall.Location = new System.Drawing.Point(393, 182);
            this.bInstall.Name = "bInstall";
            this.bInstall.Size = new System.Drawing.Size(75, 23);
            this.bInstall.TabIndex = 0;
            this.bInstall.Text = "&Install";
            this.bInstall.UseVisualStyleBackColor = true;
            this.bInstall.Click += new System.EventHandler(this.bInstall_Click);
            // 
            // tbFolder
            // 
            this.tbFolder.Location = new System.Drawing.Point(135, 105);
            this.tbFolder.Name = "tbFolder";
            this.tbFolder.Size = new System.Drawing.Size(233, 20);
            this.tbFolder.TabIndex = 1;
            // 
            // cbCreateDesktop
            // 
            this.cbCreateDesktop.AutoSize = true;
            this.cbCreateDesktop.Location = new System.Drawing.Point(38, 168);
            this.cbCreateDesktop.Name = "cbCreateDesktop";
            this.cbCreateDesktop.Size = new System.Drawing.Size(143, 17);
            this.cbCreateDesktop.TabIndex = 2;
            this.cbCreateDesktop.Text = "Create Desktop Shortcut";
            this.cbCreateDesktop.UseVisualStyleBackColor = true;
            // 
            // lFolder
            // 
            this.lFolder.AutoSize = true;
            this.lFolder.Location = new System.Drawing.Point(37, 108);
            this.lFolder.Name = "lFolder";
            this.lFolder.Size = new System.Drawing.Size(92, 13);
            this.lFolder.TabIndex = 3;
            this.lFolder.Text = "Installation Folder:";
            // 
            // lTitle
            // 
            this.lTitle.AutoSize = true;
            this.lTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTitle.Location = new System.Drawing.Point(12, 9);
            this.lTitle.Name = "lTitle";
            this.lTitle.Size = new System.Drawing.Size(264, 25);
            this.lTitle.TabIndex = 4;
            this.lTitle.Text = "SWInfo Custom Installer";
            // 
            // tbLog
            // 
            this.tbLog.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbLog.BackColor = System.Drawing.Color.White;
            this.tbLog.Location = new System.Drawing.Point(0, 211);
            this.tbLog.Multiline = true;
            this.tbLog.Name = "tbLog";
            this.tbLog.ReadOnly = true;
            this.tbLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbLog.Size = new System.Drawing.Size(482, 164);
            this.tbLog.TabIndex = 5;
            // 
            // lDescription
            // 
            this.lDescription.Location = new System.Drawing.Point(35, 41);
            this.lDescription.Name = "lDescription";
            this.lDescription.Size = new System.Drawing.Size(406, 38);
            this.lDescription.TabIndex = 7;
            this.lDescription.Text = "Welcome to the custom SWInfo installer.\r\nSpecify an installation directory and op" +
                "tions then click Install to begin the installation.";
            // 
            // cbCreateStartMenu
            // 
            this.cbCreateStartMenu.AutoSize = true;
            this.cbCreateStartMenu.Location = new System.Drawing.Point(38, 145);
            this.cbCreateStartMenu.Name = "cbCreateStartMenu";
            this.cbCreateStartMenu.Size = new System.Drawing.Size(155, 17);
            this.cbCreateStartMenu.TabIndex = 8;
            this.cbCreateStartMenu.Text = "Create Start Menu Shortcut";
            this.cbCreateStartMenu.UseVisualStyleBackColor = true;
            // 
            // lWarning
            // 
            this.lWarning.AutoSize = true;
            this.lWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lWarning.ForeColor = System.Drawing.Color.Red;
            this.lWarning.Location = new System.Drawing.Point(35, 79);
            this.lWarning.Name = "lWarning";
            this.lWarning.Size = new System.Drawing.Size(383, 13);
            this.lWarning.TabIndex = 9;
            this.lWarning.Text = "* Please make sure SolidWorks is closed down before beginning the installation.";
            // 
            // bFolderBrowse
            // 
            this.bFolderBrowse.Location = new System.Drawing.Point(374, 103);
            this.bFolderBrowse.Name = "bFolderBrowse";
            this.bFolderBrowse.Size = new System.Drawing.Size(27, 23);
            this.bFolderBrowse.TabIndex = 10;
            this.bFolderBrowse.Text = "...";
            this.bFolderBrowse.UseVisualStyleBackColor = true;
            this.bFolderBrowse.Click += new System.EventHandler(this.bFolderBrowse_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.bInstall;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 375);
            this.Controls.Add(this.bFolderBrowse);
            this.Controls.Add(this.lWarning);
            this.Controls.Add(this.cbCreateStartMenu);
            this.Controls.Add(this.lDescription);
            this.Controls.Add(this.tbLog);
            this.Controls.Add(this.lTitle);
            this.Controls.Add(this.lFolder);
            this.Controls.Add(this.cbCreateDesktop);
            this.Controls.Add(this.tbFolder);
            this.Controls.Add(this.bInstall);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SWInfo Custom Installer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bInstall;
        private System.Windows.Forms.TextBox tbFolder;
        private System.Windows.Forms.CheckBox cbCreateDesktop;
        private System.Windows.Forms.Label lFolder;
        private System.Windows.Forms.Label lTitle;
        private System.Windows.Forms.TextBox tbLog;
        private System.Windows.Forms.Label lDescription;
        private System.Windows.Forms.CheckBox cbCreateStartMenu;
        private System.Windows.Forms.Label lWarning;
        private System.Windows.Forms.Button bFolderBrowse;
    }
}

