﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Collections;
using IWshRuntimeLibrary;

namespace SWInfoCustomInstallerCS
{
    public partial class Form1 : Form
    {
        #region Variables
        Assembly        asmMe;
        AssemblyName    nameMe;
        List<string>    filesToInstall;
        List<string>    filesToRegister;
        Hashtable       filesToShortcut;

        string          regasmPath;

        string          sDesktop;
        string          sStartMenu;
        string          sProgramFiles;
        #endregion Variables

        #region Initialisation
        public Form1()
        {
            InitializeComponent();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            InitialSetup();
        }
        #endregion Initialisation

        #region Form Events
        private void bInstall_Click(object sender, EventArgs e)
        {
            StartInstall();
        }
        private void bFolderBrowse_Click(object sender, EventArgs e)
        {
            BrowseFolder();
        }
        #endregion Form Events

        #region Functions
        private void StartInstall()
        {
            // Clear log
            tbLog.Text = "";

            ToggleState(false);

            if (Install())
                Log("Installation complete.");
            else
                Log("Installation cancelled.");

            ToggleState(true);
        }

        private void InitialSetup()
        {
            // Get the location of regasm
            regasmPath = System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory() + @"regasm.exe";

            // Define list of files to install
            filesToInstall = new List<string>();
            filesToInstall.Add("readme.txt");
            filesToInstall.Add("Interop.SldWorks.dll");
            filesToInstall.Add("Interop.SwCommands.dll");
            filesToInstall.Add("Interop.SwConst.dll");
            filesToInstall.Add("Interop.SWPublished.dll");
            filesToInstall.Add("solidworkstools.dll");
            filesToInstall.Add("SWInfoCS.dll");
            filesToInstall.Add("SWInfoCS.tlb");

            // Define list of files to register
            filesToRegister = new List<string>();
            filesToRegister.Add("SWInfoCS.dll");

            // Define list of files to create shortcuts for
            // Key = filename / Value = shortcut name
            filesToShortcut = new Hashtable();
            filesToShortcut.Add("readme.txt", "SWInfo Readme");


            // Get current users special folders
            // - Desktop
            sDesktop = System.Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            // - Start Menu \ Programs
            sStartMenu = System.Environment.GetFolderPath(Environment.SpecialFolder.Programs);
            // - Program Files
            sProgramFiles = System.Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

            // Set default installation folder to Program Files\AngelSix\SWInfo
            tbFolder.Text = Path.Combine(sProgramFiles, @"AngelSix\SWInfo");
        }
        private bool Install()
        {
            // Get self
            asmMe = Assembly.GetExecutingAssembly();
            nameMe = asmMe.GetName();

            #region Create installation folder
            string installDest = tbFolder.Text;
            try
            {
                Directory.CreateDirectory(installDest);
            }
            catch
            {
                Log("Error creating installation directory " + installDest);
                return false;
            }
            #endregion Create installation folder

            // Install files
            foreach (string file in filesToInstall)
                if (!InstallFile(file, installDest))
                    return false;

            // Register files
            foreach (string file in filesToRegister)
                if (!RegisterFile(Path.Combine(installDest, file)))
                    return false;

            // Create shortcuts
            if (cbCreateDesktop.Checked || cbCreateStartMenu.Checked)
            {
                foreach (DictionaryEntry entry in filesToShortcut)
                {
                    string shortcutFile = (string)entry.Key;
                    string shortcutDesc = (string)entry.Value;

                    // Create desktop shortcut
                    if (cbCreateDesktop.Checked)
                        if (!CreateShortcut(Path.Combine(installDest, shortcutFile), sDesktop, shortcutDesc))
                            return false;

                    // Create start menu shortcut
                    if (cbCreateStartMenu.Checked)
                        if (!CreateShortcut(Path.Combine(installDest, shortcutFile), sStartMenu, shortcutDesc))
                            return false;
                }
            }

            // All done :)
            return true;
        }

        private bool InstallFile(string embeddedFile, string destination)
        {
            Log("Installing " + embeddedFile + "...");

            Stream s;
            try
            {
                s = asmMe.GetManifestResourceStream(nameMe.Name + ".Contents." + embeddedFile);
                if (s == null)
                    throw new NullReferenceException();
            }
            catch
            {
                Log("Error: Corrupt " + embeddedFile + " in installer.");
                return false;
            }

            try
            {
                using (FileStream newstream = new FileStream(Path.Combine(destination, embeddedFile), FileMode.Create))
                {
                    byte[] buffer = new byte[32768];
                    int chunkLength;
                    while ((chunkLength = s.Read(buffer, 0, buffer.Length)) > 0)
                        newstream.Write(buffer, 0, chunkLength);
                }

                s.Close();

            }
            catch
            {
                Log("Error: Error copying " + embeddedFile + " to " + destination);
                return false;
            }

            Log("Installed " + embeddedFile);

            return true;
        }
        private bool RegisterFile(string file)
        {
            Log("Registering " + file + "...");
            try
            {
                // Execute regasm
                System.Diagnostics.Process.Start(regasmPath, "/codebase \"" + file + "\"");
            }
            catch
            { 
                Log("Failed to register " + file);
                return false;
            }

            return true;
        }
        private bool CreateShortcut(string filename, string shortcutLocation, string shortcutName)
        {
            Log("Creating shortcut to " + Path.GetFileName(filename) + "...");

            try
            {
                // Create a new instance of WshShellClass
                WshShell shell = new WshShellClass();

                // Create the shortcut
                IWshRuntimeLibrary.IWshShortcut shortcut = (IWshRuntimeLibrary.IWshShortcut)shell.CreateShortcut(Path.Combine(shortcutLocation, shortcutName + ".lnk"));

                // Where the shortcut should point to
                shortcut.TargetPath = filename;

                // Description for the shortcut
                shortcut.Description = shortcutName;

                // Create the shortcut at the given path
                shortcut.Save();
            }
            catch
            {
                Log("Error creating shortcut for " + filename);
                return false;
            }

            return true;
        }

        private void ToggleState(bool enabled)
        {
            tbFolder.Enabled = bFolderBrowse.Enabled = cbCreateDesktop.Enabled = cbCreateStartMenu.Enabled = bInstall.Enabled = enabled;
        }
        private void BrowseFolder()
        {
            FolderBrowserDialog fb = new FolderBrowserDialog();
            fb.Description = "Select installation folder";
            fb.SelectedPath = tbFolder.Text;
            fb.ShowNewFolderButton = true;

            if (fb.ShowDialog(this) == DialogResult.OK)
                tbFolder.Text = fb.SelectedPath;

            fb.Dispose();
        }
        private void Log(string message)
        {
            tbLog.Text += DateTime.Now.ToShortTimeString() + ": " + message + Environment.NewLine;
            tbLog.SelectionStart = tbLog.Text.Length - 1;
            tbLog.ScrollToCaret();
        }

        #endregion Functions
    }
}
