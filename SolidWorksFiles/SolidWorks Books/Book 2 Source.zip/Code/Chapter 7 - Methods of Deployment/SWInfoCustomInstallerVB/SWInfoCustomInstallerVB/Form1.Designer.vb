﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.bFolderBrowse = New System.Windows.Forms.Button
        Me.lWarning = New System.Windows.Forms.Label
        Me.cbCreateStartMenu = New System.Windows.Forms.CheckBox
        Me.lDescription = New System.Windows.Forms.Label
        Me.tbLog = New System.Windows.Forms.TextBox
        Me.lTitle = New System.Windows.Forms.Label
        Me.lFolder = New System.Windows.Forms.Label
        Me.cbCreateDesktop = New System.Windows.Forms.CheckBox
        Me.tbFolder = New System.Windows.Forms.TextBox
        Me.bInstall = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'bFolderBrowse
        '
        Me.bFolderBrowse.Location = New System.Drawing.Point(374, 103)
        Me.bFolderBrowse.Name = "bFolderBrowse"
        Me.bFolderBrowse.Size = New System.Drawing.Size(27, 23)
        Me.bFolderBrowse.TabIndex = 21
        Me.bFolderBrowse.Text = "..."
        Me.bFolderBrowse.UseVisualStyleBackColor = True
        '
        'lWarning
        '
        Me.lWarning.AutoSize = True
        Me.lWarning.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lWarning.ForeColor = System.Drawing.Color.Red
        Me.lWarning.Location = New System.Drawing.Point(35, 79)
        Me.lWarning.Name = "lWarning"
        Me.lWarning.Size = New System.Drawing.Size(383, 13)
        Me.lWarning.TabIndex = 20
        Me.lWarning.Text = "* Please make sure SolidWorks is closed down before beginning the installation."
        '
        'cbCreateStartMenu
        '
        Me.cbCreateStartMenu.AutoSize = True
        Me.cbCreateStartMenu.Location = New System.Drawing.Point(38, 145)
        Me.cbCreateStartMenu.Name = "cbCreateStartMenu"
        Me.cbCreateStartMenu.Size = New System.Drawing.Size(155, 17)
        Me.cbCreateStartMenu.TabIndex = 19
        Me.cbCreateStartMenu.Text = "Create Start Menu Shortcut"
        Me.cbCreateStartMenu.UseVisualStyleBackColor = True
        '
        'lDescription
        '
        Me.lDescription.Location = New System.Drawing.Point(35, 41)
        Me.lDescription.Name = "lDescription"
        Me.lDescription.Size = New System.Drawing.Size(406, 38)
        Me.lDescription.TabIndex = 18
        Me.lDescription.Text = "Welcome to the custom SWInfo installer." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Specify an installation directory and op" & _
            "tions then click Install to begin the installation."
        '
        'tbLog
        '
        Me.tbLog.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbLog.BackColor = System.Drawing.Color.White
        Me.tbLog.Location = New System.Drawing.Point(0, 211)
        Me.tbLog.Multiline = True
        Me.tbLog.Name = "tbLog"
        Me.tbLog.ReadOnly = True
        Me.tbLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbLog.Size = New System.Drawing.Size(482, 164)
        Me.tbLog.TabIndex = 16
        '
        'lTitle
        '
        Me.lTitle.AutoSize = True
        Me.lTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lTitle.Location = New System.Drawing.Point(12, 9)
        Me.lTitle.Name = "lTitle"
        Me.lTitle.Size = New System.Drawing.Size(264, 25)
        Me.lTitle.TabIndex = 15
        Me.lTitle.Text = "SWInfo Custom Installer"
        '
        'lFolder
        '
        Me.lFolder.AutoSize = True
        Me.lFolder.Location = New System.Drawing.Point(37, 108)
        Me.lFolder.Name = "lFolder"
        Me.lFolder.Size = New System.Drawing.Size(92, 13)
        Me.lFolder.TabIndex = 14
        Me.lFolder.Text = "Installation Folder:"
        '
        'cbCreateDesktop
        '
        Me.cbCreateDesktop.AutoSize = True
        Me.cbCreateDesktop.Location = New System.Drawing.Point(38, 168)
        Me.cbCreateDesktop.Name = "cbCreateDesktop"
        Me.cbCreateDesktop.Size = New System.Drawing.Size(143, 17)
        Me.cbCreateDesktop.TabIndex = 13
        Me.cbCreateDesktop.Text = "Create Desktop Shortcut"
        Me.cbCreateDesktop.UseVisualStyleBackColor = True
        '
        'tbFolder
        '
        Me.tbFolder.Location = New System.Drawing.Point(135, 105)
        Me.tbFolder.Name = "tbFolder"
        Me.tbFolder.Size = New System.Drawing.Size(233, 20)
        Me.tbFolder.TabIndex = 12
        '
        'bInstall
        '
        Me.bInstall.Location = New System.Drawing.Point(393, 182)
        Me.bInstall.Name = "bInstall"
        Me.bInstall.Size = New System.Drawing.Size(75, 23)
        Me.bInstall.TabIndex = 11
        Me.bInstall.Text = "&Install"
        Me.bInstall.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.bInstall
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 375)
        Me.Controls.Add(Me.bFolderBrowse)
        Me.Controls.Add(Me.lWarning)
        Me.Controls.Add(Me.cbCreateStartMenu)
        Me.Controls.Add(Me.lDescription)
        Me.Controls.Add(Me.tbLog)
        Me.Controls.Add(Me.lTitle)
        Me.Controls.Add(Me.lFolder)
        Me.Controls.Add(Me.cbCreateDesktop)
        Me.Controls.Add(Me.tbFolder)
        Me.Controls.Add(Me.bInstall)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SwInfo Custom Installer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents bFolderBrowse As System.Windows.Forms.Button
    Private WithEvents lWarning As System.Windows.Forms.Label
    Private WithEvents cbCreateStartMenu As System.Windows.Forms.CheckBox
    Private WithEvents lDescription As System.Windows.Forms.Label
    Private WithEvents tbLog As System.Windows.Forms.TextBox
    Private WithEvents lTitle As System.Windows.Forms.Label
    Private WithEvents lFolder As System.Windows.Forms.Label
    Private WithEvents cbCreateDesktop As System.Windows.Forms.CheckBox
    Private WithEvents tbFolder As System.Windows.Forms.TextBox
    Private WithEvents bInstall As System.Windows.Forms.Button

End Class
