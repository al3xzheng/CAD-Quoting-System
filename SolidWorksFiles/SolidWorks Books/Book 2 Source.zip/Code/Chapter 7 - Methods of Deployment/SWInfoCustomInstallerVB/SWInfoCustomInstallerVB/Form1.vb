﻿Imports System.IO
Imports System.Reflection
Imports System.Collections
Imports IWshRuntimeLibrary

Public Class Form1

#Region "Variables"
    Dim asmMe As Assembly
    Dim nameMe As AssemblyName
    Dim filesToInstall As List(Of String)
    Dim filesToRegister As List(Of String)
    Dim filesToShortcut As Hashtable

    Dim regasmPath As String

    Dim sDesktop As String
    Dim sStartMenu As String
    Dim sProgramFiles As String

#End Region

#Region "Form Events"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitialSetup()
    End Sub

    Private Sub bFolderBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bFolderBrowse.Click
        BrowseFolder()
    End Sub

    Private Sub bInstall_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bInstall.Click
        StartInstall()
    End Sub

#End Region

#Region "Functions"

    Private Sub StartInstall()
        ' Clear log
        tbLog.Text = ""

        ToggleState(False)

        If (Install()) Then
            Log("Installation complete.")
        Else
            Log("Installation cancelled.")
        End If

        ToggleState(True)

    End Sub

    Private Sub InitialSetup()
        ' Get the location of regasm
        regasmPath = System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory() + "regasm.exe"

        ' Define list of files to install
        filesToInstall = New List(Of String)
        filesToInstall.Add("readme.txt")
        filesToInstall.Add("Interop.SldWorks.dll")
        filesToInstall.Add("Interop.SwCommands.dll")
        filesToInstall.Add("Interop.SwConst.dll")
        filesToInstall.Add("Interop.SWPublished.dll")
        filesToInstall.Add("solidworkstools.dll")
        filesToInstall.Add("SWInfoCS.dll")
        filesToInstall.Add("SWInfoCS.tlb")

        ' Define list of files to register
        filesToRegister = New List(Of String)
        filesToRegister.Add("SWInfoCS.dll")

        ' Define list of files to create shortcuts for
        ' Key = filename / Value = shortcut name
        filesToShortcut = New Hashtable()
        filesToShortcut.Add("readme.txt", "SWInfo Readme")

        ' Get current users special folders
        ' - Desktop
        sDesktop = System.Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        ' - Start Menu \ Programs
        sStartMenu = System.Environment.GetFolderPath(Environment.SpecialFolder.Programs)
        ' - Program Files
        sProgramFiles = System.Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)

        ' Set default installation folder to Program Files\AngelSix\SWInfo
        tbFolder.Text = Path.Combine(sProgramFiles, "AngelSix\SWInfo")

    End Sub

    Private Function Install() As Boolean
        ' Get self
        asmMe = Assembly.GetExecutingAssembly()
        nameMe = asmMe.GetName()

        ' "Create installation folder"
        Dim installDest As String = tbFolder.Text
        Try
            Directory.CreateDirectory(installDest)
        Catch
            Log("Error creating installation directory " + installDest)
            Return False
        End Try


        ' Install files
        For Each file As String In filesToInstall
            If Not InstallFile(file, installDest) Then Return False
        Next

        ' Register files
        For Each file As String In filesToRegister
            If Not RegisterFile(Path.Combine(installDest, file)) Then Return False
        Next

        ' Create shortcuts
        If (cbCreateDesktop.Checked Or cbCreateStartMenu.Checked) Then
            For Each entry As DictionaryEntry In filesToShortcut
                Dim shortcutFile As String = entry.Key
                Dim shortcutDesc As String = entry.Value

                ' Create desktop shortcut
                If cbCreateDesktop.Checked Then
                    If Not CreateShortcut(Path.Combine(installDest, shortcutFile), sDesktop, shortcutDesc) Then Return False
                End If

                ' Create start menu shortcut
                If cbCreateStartMenu.Checked Then
                    If Not CreateShortcut(Path.Combine(installDest, shortcutFile), sStartMenu, shortcutDesc) Then Return False
                End If
            Next
        End If

        ' All done :)
        Return True

    End Function

    Private Function InstallFile(ByVal embeddedFile As String, ByVal destination As String) As Boolean
        Log("Installing " + embeddedFile + "...")

        Dim s As Stream
        Try
            s = asmMe.GetManifestResourceStream(nameMe.Name + "." + embeddedFile)
            If s Is Nothing Then Throw New NullReferenceException()
        Catch
            Log("Error: Corrupt " + embeddedFile + " in installer.")
            Return False
        End Try

        Try

            Using newstream As FileStream = New FileStream(Path.Combine(destination, embeddedFile), FileMode.Create)
                Dim buffer(32768) As Byte

                Dim chunkLength As Integer = s.Read(buffer, 0, buffer.Length)
                While (chunkLength > 0)
                    newstream.Write(buffer, 0, chunkLength)
                    chunkLength = s.Read(buffer, 0, buffer.Length)
                End While
            End Using
            s.Close()
        Catch
            Log("Error: Error copying " + embeddedFile + " to " + destination)
            Return False
        End Try

        Log("Installed " + embeddedFile)

        Return True
    End Function

    Private Function RegisterFile(ByVal file As String) As Boolean
        Log("Registering " + file + "...")
        Try
            ' Execute regasm
            System.Diagnostics.Process.Start(regasmPath, "/codebase """ + file + """")
        Catch e As Exception
            Log("Failed to register " + file)
            Return False
        End Try

        Return True
    End Function

    Private Function CreateShortcut(ByVal filename As String, ByVal shortcutLocation As String, ByVal shortcutName As String) As Boolean
        Log("Creating shortcut to " + Path.GetFileName(filename) + "...")

        Try
            ' Create a new instance of WshShellClass
            Dim shell As WshShell = New WshShellClass()

            ' Create the shortcut
            Dim shortcut As IWshRuntimeLibrary.IWshShortcut = shell.CreateShortcut(Path.Combine(shortcutLocation, shortcutName + ".lnk"))

            ' Where the shortcut should point to
            shortcut.TargetPath = filename

            ' Description for the shortcut
            shortcut.Description = shortcutName

            ' Create the shortcut at the given path
            shortcut.Save()
        Catch
            Log("Error creating shortcut for " + filename)
            Return False
        End Try

        Return True
    End Function

    Private Sub ToggleState(ByVal enabled As Boolean)
        tbFolder.Enabled = bFolderBrowse.Enabled = cbCreateDesktop.Enabled = cbCreateStartMenu.Enabled = bInstall.Enabled = enabled
    End Sub

    Private Sub BrowseFolder()
        Dim fb As FolderBrowserDialog = New FolderBrowserDialog()
        fb.Description = "Select installation folder"
        fb.SelectedPath = tbFolder.Text
        fb.ShowNewFolderButton = True

        If fb.ShowDialog(Me) = DialogResult.OK Then tbFolder.Text = fb.SelectedPath

        fb.Dispose()
    End Sub

    Private Sub Log(ByVal message As String)
        tbLog.Text += DateTime.Now.ToShortTimeString() + ": " + message + Environment.NewLine
        tbLog.SelectionStart = tbLog.Text.Length - 1
        tbLog.ScrollToCaret()
    End Sub

#End Region

End Class
