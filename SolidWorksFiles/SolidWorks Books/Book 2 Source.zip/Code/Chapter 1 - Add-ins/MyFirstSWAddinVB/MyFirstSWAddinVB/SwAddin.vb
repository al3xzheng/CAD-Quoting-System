﻿Imports System.Runtime.InteropServices

Imports SldWorks
Imports SWPublished
Imports SwConst
Imports SwCommands

Imports SolidWorksTools
Imports SolidWorksTools.File

<Guid("C918F0DD-8D03-406d-8DC0-79A2892159D6"), ComVisible(True)> _
<SwAddin(Description:="This is my first SW Addin", Title:="MyFirstSWAddin", LoadAtStartup:=True)> _
Public Class SwAddin
    Implements SWPublished.SwAddin

    Dim iSwApp As SldWorks.SldWorks

    Public Function ConnectToSW(ByVal ThisSW As Object, ByVal Cookie As Integer) As Boolean Implements SWPublished.ISwAddin.ConnectToSW
        iSwApp = ThisSW
        iSwApp.SendMsgToUser2("Hello!", swMessageBoxIcon_e.swMbInformation, swMessageBoxBtn_e.swMbOk)
        ConnectToSW = True
    End Function

    Public Function DisconnectFromSW() As Boolean Implements SWPublished.ISwAddin.DisconnectFromSW
        iSwApp.SendMsgToUser2("Bye!", swMessageBoxIcon_e.swMbInformation, swMessageBoxBtn_e.swMbOk)
        iSwApp = Nothing
        GC.Collect()
        DisconnectFromSW = True
    End Function

    <ComRegisterFunction()> Public Shared Sub RegisterFunction(ByVal t As Type)

        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        Dim addinkey As Microsoft.Win32.RegistryKey = hklm.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 0)
        addinkey.SetValue("Description", "Sample Addin")
        addinkey.SetValue("Title", "MyFirstAddin")

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        addinkey = hkcu.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 1)
    End Sub

    <ComUnregisterFunction()> Public Shared Sub UnregisterFunction(ByVal t As Type)
        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        hklm.DeleteSubKey(keyname)

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        hkcu.DeleteSubKey(keyname)
    End Sub


End Class
