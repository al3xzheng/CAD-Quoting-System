﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

using SldWorks;
using SWPublished;
using SwConst;
using SwCommands;

using SolidWorksTools;
using SolidWorksTools.File;

namespace DrawingInfoPropertyPageCS
{
    [Guid("883d6c36-100b-4036-a888-27c88b394882"), ComVisible(true)]
    [SwAddin(Description = "DrawingInfo PropertyPage", Title = "DrawingInfo PropertyPage", LoadAtStartup = true)]
    public class MyAddin : ISwAddin
    {
        ISldWorks iSwApp;
        ICommandManager iCmdMgr;
        MyPMPManager myPMP;

        #region Connection
        public bool ConnectToSW(object ThisSW, int Cookie)
        {
            iSwApp = (ISldWorks)ThisSW;

            iSwApp.SetAddinCallbackInfo(0, this, Cookie);

            iCmdMgr = iSwApp.GetCommandManager(Cookie);
            AddCommandMgr();

            return true;
        }

        public bool DisconnectFromSW()
        {
            RemoveCommandMgr();
            RemovePMP();

            iSwApp = null;
            GC.Collect();
            return true;
        }
        #endregion Connection

        #region COM Registration
        [ComRegisterFunctionAttribute]
        public static void RegisterFunction(Type t)
        {
            Microsoft.Win32.RegistryKey hklm = Microsoft.Win32.Registry.LocalMachine;
            Microsoft.Win32.RegistryKey hkcu = Microsoft.Win32.Registry.CurrentUser;

            string keyname = "SOFTWARE\\SolidWorks\\Addins\\{" + t.GUID.ToString() + "}";
            Microsoft.Win32.RegistryKey addinkey = hklm.CreateSubKey(keyname);
            addinkey.SetValue(null, 0);
            addinkey.SetValue("Description", "DrawingInfo PropertyPage");
            addinkey.SetValue("Title", "DrawingInfo PropertyPage");

            keyname = "Software\\SolidWorks\\AddInsStartup\\{" + t.GUID.ToString() + "}";
            addinkey = hkcu.CreateSubKey(keyname);
            addinkey.SetValue(null, 1);
        }

        [ComUnregisterFunctionAttribute]
        public static void UnregisterFunction(Type t)
        {
            //Insert code here.
            Microsoft.Win32.RegistryKey hklm = Microsoft.Win32.Registry.LocalMachine;
            Microsoft.Win32.RegistryKey hkcu = Microsoft.Win32.Registry.CurrentUser;

            string keyname = "SOFTWARE\\SolidWorks\\Addins\\{" + t.GUID.ToString() + "}";
            hklm.DeleteSubKey(keyname);

            keyname = "Software\\SolidWorks\\AddInsStartup\\{" + t.GUID.ToString() + "}";
            hkcu.DeleteSubKey(keyname);
        }
        #endregion COM Registration

        public void AddCommandMgr()
        {
            ICommandGroup cmdGroup;

            cmdGroup = iCmdMgr.CreateCommandGroup(1, "DrawingInfo Property Page", "Click my items!", "My status description", 3);

            cmdGroup.AddCommandItem2("Create PMP", 0, "Creates a Property Page", "Click me!", 0, "_cbCreatePMP", "", 0, (int)(swCommandItemType_e.swMenuItem | swCommandItemType_e.swToolbarItem));

            cmdGroup.HasToolbar = true;
            cmdGroup.HasMenu = true;
            cmdGroup.Activate();
        }

        public void RemoveCommandMgr()
        {
            iCmdMgr.RemoveCommandGroup(1);
        }

        public void RemovePMP()
        {
            myPMP = null;
        }

        public void _cbCreatePMP()
        {
            myPMP = new MyPMPManager((SldWorks.SldWorks)iSwApp);
            if (myPMP.OK)
                myPMP.Show();
        }
    }
}
