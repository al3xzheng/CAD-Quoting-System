﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

using SldWorks;
using SWPublished;
using SwConst;
using SwCommands;

using SolidWorksTools;
using SolidWorksTools.File;

namespace DrawingInfoPropertyPageCS
{
    public class MyPMPManager : IPropertyManagerPage2Handler6
    {
        SldWorks.ISldWorks swApp;
        IPropertyManagerPage2 pmPage;
        int iErrors;
        public bool OK;

        int uidLabelFilename, uidButtonUpdate;
        PropertyManagerPageLabel ctrLabelFilename;
        PropertyManagerPageButton ctrButtonUpdate;

        public MyPMPManager(SldWorks.ISldWorks app)
        {
            swApp = app;

            try
            {
                // Create new page
                pmPage = (IPropertyManagerPage2)swApp.CreatePropertyManagerPage("DrawingSheet Info", (int)(swPropertyManagerPageOptions_e.swPropertyManagerOptions_OkayButton | swPropertyManagerPageOptions_e.swPropertyManagerOptions_LockedPage), this, ref iErrors);

                // Check if was created proeprly
                if (iErrors != (int)swPropertyManagerPageStatus_e.swPropertyManagerPage_Okay)
                {
                    swApp.SendMsgToUser2("Error creating PMP: " + ((swPropertyManagerPageStatus_e)iErrors).ToString(), (int)swMessageBoxIcon_e.swMbWarning, (int)swMessageBoxBtn_e.swMbOk);
                    OK = false;
                    return;
                }

                OK = true;
            }
            catch (Exception e)
            {
                swApp.SendMsgToUser2("Error creating PMP: " + e.Message, (int)swMessageBoxIcon_e.swMbWarning, (int)swMessageBoxBtn_e.swMbOk);
                OK = false;
            }

            if (OK)
                AddControls();
        }

        private void AddControls()
        {
            pmPage.SetMessage3("This page will pull in information from the active drawing", (int)swPropertyManagerPageMessageVisibility.swImportantMessageBox, (int)swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Caption");

            // Set IDs
            uidLabelFilename = 1;
            uidButtonUpdate = 2;

            // Set Defaults
            int iStandardOption = (int)(swAddControlOptions_e.swControlOptions_Enabled | swAddControlOptions_e.swControlOptions_Visible);
            short sStandardAlign = (short)swPropertyManagerPageControlLeftAlign_e.swControlAlign_LeftEdge;

            // Add Label: Filename
            ctrLabelFilename = (PropertyManagerPageLabel)pmPage.AddControl(uidLabelFilename, (short)swPropertyManagerPageControlType_e.swControlType_Label, "Drawing Filename here", sStandardAlign, iStandardOption, "Drawing Filename");
            // Add Button: Update
            ctrButtonUpdate = (PropertyManagerPageButton)pmPage.AddControl(uidButtonUpdate, (short)swPropertyManagerPageControlType_e.swControlType_Button, "Update Details", sStandardAlign, iStandardOption, "Update Drawing Information");
        }

        public void Show()
        {
            pmPage.Show2(0);
        }

        #region IPropertyManagerPage2Handler6 Members

        public void AfterActivation()
        {

        }

        public void AfterClose()
        {
            pmPage = null;
        }

        public int OnActiveXControlCreated(int Id, bool Status)
        {
            return 0;
        }

        public void OnButtonPress(int Id)
        {

        }

        public void OnCheckboxCheck(int Id, bool Checked)
        {

        }

        public void OnClose(int Reason)
        {

        }

        public void OnComboboxEditChanged(int Id, string Text)
        {

        }

        public void OnComboboxSelectionChanged(int Id, int Item)
        {

        }

        public void OnGroupCheck(int Id, bool Checked)
        {

        }

        public void OnGroupExpand(int Id, bool Expanded)
        {

        }

        public bool OnHelp()
        {
            return false;
        }

        public bool OnKeystroke(int Wparam, int Message, int Lparam, int Id)
        {
            return false;
        }

        public void OnListboxSelectionChanged(int Id, int Item)
        {

        }

        public bool OnNextPage()
        {
            return false;
        }

        public void OnNumberboxChanged(int Id, double Value)
        {

        }

        public void OnOptionCheck(int Id)
        {

        }

        public void OnPopupMenuItem(int Id)
        {

        }

        public void OnPopupMenuItemUpdate(int Id, ref int retval)
        {

        }

        public bool OnPreview()
        {
            return false;
        }

        public bool OnPreviousPage()
        {
            return false;
        }

        public void OnRedo()
        {

        }

        public void OnSelectionboxCalloutCreated(int Id)
        {

        }

        public void OnSelectionboxCalloutDestroyed(int Id)
        {

        }

        public void OnSelectionboxFocusChanged(int Id)
        {

        }

        public void OnSelectionboxListChanged(int Id, int Count)
        {

        }

        public void OnSliderPositionChanged(int Id, double Value)
        {

        }

        public void OnSliderTrackingCompleted(int Id, double Value)
        {

        }

        public bool OnSubmitSelection(int Id, object Selection, int SelType, ref string ItemText)
        {
            return false;
        }

        public bool OnTabClicked(int Id)
        {
            return false;
        }

        public void OnTextboxChanged(int Id, string Text)
        {

        }

        public void OnUndo()
        {

        }

        public void OnWhatsNew()
        {

        }

        #endregion
    }
}
