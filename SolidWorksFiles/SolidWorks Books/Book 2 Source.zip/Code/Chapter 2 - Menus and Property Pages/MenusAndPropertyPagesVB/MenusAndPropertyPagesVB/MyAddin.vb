﻿Imports System.Runtime.InteropServices

Imports SldWorks
Imports SWPublished
Imports SwConst
Imports SwCommands

Imports SolidWorksTools
Imports SolidWorksTools.File

<Guid("C918F0DD-8D03-406d-8DC0-79A2892159D6"), ComVisible(True)> _
<SwAddin(Description:="Menus and PropertyPages", Title:="Menus and PropertyPages", LoadAtStartup:=True)> _
Public Class MyAddin
    Implements SWPublished.SwAddin

    Dim iSwApp As SldWorks.SldWorks
    Dim iCmdMgr As SldWorks.CommandManager

    Public Function ConnectToSW(ByVal ThisSW As Object, ByVal Cookie As Integer) As Boolean Implements SWPublished.ISwAddin.ConnectToSW
        iSwApp = ThisSW

        iSwApp.SetAddinCallbackInfo(0, Me, Cookie)

        iCmdMgr = iSwApp.GetCommandManager(Cookie)
        AddCommandMgr()

        ConnectToSW = True
    End Function

    Public Function DisconnectFromSW() As Boolean Implements SWPublished.ISwAddin.DisconnectFromSW
        RemoveCommandMgr()
        iSwApp = Nothing
        GC.Collect()
        DisconnectFromSW = True
    End Function

    <ComRegisterFunction()> Public Shared Sub RegisterFunction(ByVal t As Type)

        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        Dim addinkey As Microsoft.Win32.RegistryKey = hklm.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 0)
        addinkey.SetValue("Description", "Sample Addin")
        addinkey.SetValue("Title", "MyFirstAddin")

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        addinkey = hkcu.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 1)
    End Sub

    <ComUnregisterFunction()> Public Shared Sub UnregisterFunction(ByVal t As Type)
        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        hklm.DeleteSubKey(keyname)

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        hkcu.DeleteSubKey(keyname)
    End Sub

    Public Sub AddCommandMgr()
        Dim cmdGroup As CommandGroup

        cmdGroup = iCmdMgr.CreateCommandGroup(1, "MyAddin Menu 1", "Click my items!", "My status description", 3)

        cmdGroup.AddCommandItem2("Create PMP", 0, "Creates a Property Page", "Click me!", 0, "_cbCreatePMP", "", 0, swCommandItemType_e.swMenuItem Or swCommandItemType_e.swToolbarItem)

        cmdGroup.HasMenu = True
        cmdGroup.HasToolbar = True
        cmdGroup.Activate()
    End Sub

    Public Sub RemoveCommandMgr()
        iCmdMgr.RemoveCommandGroup(1)
    End Sub

    Public Sub _cbCreatePMP()
        iSwApp.SendMsgToUser2("I will create a PropertyManagerPage item later", swMessageBoxIcon_e.swMbInformation, swMessageBoxBtn_e.swMbOk)
    End Sub

End Class
