﻿Imports System.Runtime.InteropServices

Imports SldWorks
Imports SWPublished
Imports SwConst
Imports SwCommands

Imports SolidWorksTools
Imports SolidWorksTools.File

Public Class MyPMPMananger
    Implements PropertyManagerPage2Handler6

    Dim swApp As SldWorks.SldWorks
    Dim pmPage As PropertyManagerPage2
    Dim iErrors As Integer
    Public OK As Boolean

    Dim uidLabelFilename As Integer, _
        uidButtonUpdate As Integer
    Dim ctrLabelFilename As PropertyManagerPageLabel
    Dim ctrButtonUpdate As PropertyManagerPageButton

    Public Sub New(ByVal app As SldWorks.SldWorks)
        swApp = app

        Try
            ' Create new PMP
            pmPage = app.CreatePropertyManagerPage("DrawingSheet Info", swPropertyManagerPageOptions_e.swPropertyManagerOptions_OkayButton Or swPropertyManagerPageOptions_e.swPropertyManagerOptions_LockedPage, Me, iErrors)

            ' Check if was created proeprly
            If iErrors <> swPropertyManagerPageStatus_e.swPropertyManagerPage_Okay Then
                swApp.SendMsgToUser2("Error creating PMP: " + CType(iErrors, swPropertyManagerPageStatus_e).ToString(), swMessageBoxIcon_e.swMbWarning, swMessageBoxBtn_e.swMbOk)
                OK = False
                Return
            End If

            OK = True
        Catch ex As Exception
            swApp.SendMsgToUser2("Error creating PMP: " + ex.Message, swMessageBoxIcon_e.swMbWarning, swMessageBoxBtn_e.swMbOk)
            OK = False
        End Try

        If OK Then AddControls()

    End Sub

    Public Sub AddControls()
        pmPage.SetMessage3("This page will pull in information from the active drawing", swPropertyManagerPageMessageVisibility.swImportantMessageBox, swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Caption")

        ' Set IDs
        uidLabelFilename = 1
        uidButtonUpdate = 2

        ' Set Defaults
        Dim iStandardOption As Integer = swAddControlOptions_e.swControlOptions_Enabled Or swAddControlOptions_e.swControlOptions_Visible
        Dim sStandardAlign As Short = swPropertyManagerPageControlLeftAlign_e.swControlAlign_LeftEdge

        ' Add Label: Filename
        ctrLabelFilename = pmPage.AddControl(uidLabelFilename, swPropertyManagerPageControlType_e.swControlType_Label, "Drawing Filename here", sStandardAlign, iStandardOption, "Drawing Filename")

        ' Add Button: Update
        ctrButtonUpdate = pmPage.AddControl(uidButtonUpdate, swPropertyManagerPageControlType_e.swControlType_Button, "Update Details", sStandardAlign, iStandardOption, "Update Drawing Information")
    End Sub

    Public Sub Show()
        pmPage.Show2(0)
    End Sub

    Public Sub AfterActivation() Implements SWPublished.IPropertyManagerPage2Handler6.AfterActivation

    End Sub

    Public Sub AfterClose() Implements SWPublished.IPropertyManagerPage2Handler6.AfterClose
        pmPage = Nothing
    End Sub

    Public Function OnActiveXControlCreated(ByVal Id As Integer, ByVal Status As Boolean) As Integer Implements SWPublished.IPropertyManagerPage2Handler6.OnActiveXControlCreated

    End Function

    Public Sub OnButtonPress(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnButtonPress

    End Sub

    Public Sub OnCheckboxCheck(ByVal Id As Integer, ByVal Checked As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnCheckboxCheck

    End Sub

    Public Sub OnClose(ByVal Reason As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnClose

    End Sub

    Public Sub OnComboboxEditChanged(ByVal Id As Integer, ByVal Text As String) Implements SWPublished.IPropertyManagerPage2Handler6.OnComboboxEditChanged

    End Sub

    Public Sub OnComboboxSelectionChanged(ByVal Id As Integer, ByVal Item As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnComboboxSelectionChanged

    End Sub

    Public Sub OnGroupCheck(ByVal Id As Integer, ByVal Checked As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnGroupCheck

    End Sub

    Public Sub OnGroupExpand(ByVal Id As Integer, ByVal Expanded As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnGroupExpand

    End Sub

    Public Function OnHelp() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnHelp

    End Function

    Public Function OnKeystroke(ByVal Wparam As Integer, ByVal Message As Integer, ByVal Lparam As Integer, ByVal Id As Integer) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnKeystroke

    End Function

    Public Sub OnListboxSelectionChanged(ByVal Id As Integer, ByVal Item As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnListboxSelectionChanged

    End Sub

    Public Function OnNextPage() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnNextPage

    End Function

    Public Sub OnNumberboxChanged(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnNumberboxChanged

    End Sub

    Public Sub OnOptionCheck(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnOptionCheck

    End Sub

    Public Sub OnPopupMenuItem(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnPopupMenuItem

    End Sub

    Public Sub OnPopupMenuItemUpdate(ByVal Id As Integer, ByRef retval As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnPopupMenuItemUpdate

    End Sub

    Public Function OnPreview() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnPreview

    End Function

    Public Function OnPreviousPage() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnPreviousPage

    End Function

    Public Sub OnRedo() Implements SWPublished.IPropertyManagerPage2Handler6.OnRedo

    End Sub

    Public Sub OnSelectionboxCalloutCreated(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxCalloutCreated

    End Sub

    Public Sub OnSelectionboxCalloutDestroyed(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxCalloutDestroyed

    End Sub

    Public Sub OnSelectionboxFocusChanged(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxFocusChanged

    End Sub

    Public Sub OnSelectionboxListChanged(ByVal Id As Integer, ByVal Count As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxListChanged

    End Sub

    Public Sub OnSliderPositionChanged(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnSliderPositionChanged

    End Sub

    Public Sub OnSliderTrackingCompleted(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnSliderTrackingCompleted

    End Sub

    Public Function OnSubmitSelection(ByVal Id As Integer, ByVal Selection As Object, ByVal SelType As Integer, ByRef ItemText As String) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnSubmitSelection

    End Function

    Public Function OnTabClicked(ByVal Id As Integer) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnTabClicked

    End Function

    Public Sub OnTextboxChanged(ByVal Id As Integer, ByVal Text As String) Implements SWPublished.IPropertyManagerPage2Handler6.OnTextboxChanged

    End Sub

    Public Sub OnUndo() Implements SWPublished.IPropertyManagerPage2Handler6.OnUndo

    End Sub

    Public Sub OnWhatsNew() Implements SWPublished.IPropertyManagerPage2Handler6.OnWhatsNew

    End Sub
End Class