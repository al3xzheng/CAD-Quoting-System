﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

public class Form1 : Form
{
    private StreamWriter swLog;
    private string sLogFilename;

    public Form1()
    {
        InitialiseLog();
        Log(" ");
        Log("Form starting");
        Log("========================");

        Log("About to initialise i");
        int i = 0;
        Log("i = " + i.ToString());
        Log("About to initialise j");
        int j = 1;
        Log("j = " + j.ToString());
        Log("About to divide j / i");
        int k = j / i;
        Log("k = " + k.ToString());
    }

    private void Log(string message)
    {
        // Create log or open existing
        swLog = new StreamWriter(sLogFilename, true);
        swLog.WriteLine(DateTime.Now.ToString("dd/MM/yy hh:mm:ss") + " " + message);
        swLog.Close();
    }

    private void InitialiseLog()
    {
        // Get this exe location and append a \log.txt to it
        sLogFilename = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "log.txt");
    }
}