﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace EventLogCS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("eventvwr.msc");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!EventLog.SourceExists(tbSource.Text))
                EventLog.CreateEventSource(tbSource.Text, tbName.Text);

            EventLog.WriteEntry(tbSource.Text, tbEvent.Text);
        }
    }
}
