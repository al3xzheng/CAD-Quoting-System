﻿Imports System.IO
Imports System.Reflection

Public Class Form1
    Private swLog As StreamWriter
    Private sLogFilename As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        InitialiseLog()
        Log(" ")
        Log("Form starting")
        Log("========================")

        Log("About to initialise i")
        Dim i As Integer = 0
        Log("i = " + i.ToString())
        Log("About to initialise j")
        Dim j As Integer = 1
        Log("j = " + j.ToString())
        Log("About to divide j / i")
        Dim k As Integer = j / i
        Log("k = " + k.ToString())
    End Sub

    Private Sub Log(ByVal message As String)
        ' Create log or open existing
        swLog = New StreamWriter(sLogFilename, True)
        swLog.WriteLine(DateTime.Now.ToString("dd/MM/yy hh:mm:ss") + " " + message)
        swLog.Close()
    End Sub

    Private Sub InitialiseLog()
        ' Get this exe location and appwend a \log.txt to it

        sLogFilename = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "log.txt")
    End Sub
End Class
