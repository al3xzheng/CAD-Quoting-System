﻿using System;
using System.Windows.Forms;

public class Form1 : Form
{
    public Form1()
    {
        int i = 0;
        int j = 1;
        int k = j / i;
    }
}