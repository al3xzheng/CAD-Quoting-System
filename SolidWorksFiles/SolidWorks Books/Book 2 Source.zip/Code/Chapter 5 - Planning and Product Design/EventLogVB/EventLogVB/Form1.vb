﻿Imports System.Diagnostics

Public Class Form1

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Process.Start("eventvwr.msc")
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If (Not EventLog.SourceExists(tbSource.Text)) Then EventLog.CreateEventSource(tbSource.Text, tbName.Text)

        EventLog.WriteEntry(tbSource.Text, tbEvent.Text)
    End Sub
End Class
