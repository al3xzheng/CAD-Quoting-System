﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.tbEvent = New System.Windows.Forms.TextBox
        Me.tbName = New System.Windows.Forms.TextBox
        Me.tbSource = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(188, 134)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 15
        Me.button2.Text = "View Log"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(188, 105)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 14
        Me.button1.Text = "Add Entry"
        Me.button1.UseVisualStyleBackColor = True
        '
        'tbEvent
        '
        Me.tbEvent.Location = New System.Drawing.Point(96, 79)
        Me.tbEvent.Name = "tbEvent"
        Me.tbEvent.Size = New System.Drawing.Size(167, 20)
        Me.tbEvent.TabIndex = 13
        Me.tbEvent.Text = "Watch me get added!"
        '
        'tbName
        '
        Me.tbName.Location = New System.Drawing.Point(96, 10)
        Me.tbName.Name = "tbName"
        Me.tbName.Size = New System.Drawing.Size(167, 20)
        Me.tbName.TabIndex = 12
        Me.tbName.Text = "MyEventLog"
        '
        'tbSource
        '
        Me.tbSource.Location = New System.Drawing.Point(96, 53)
        Me.tbSource.Name = "tbSource"
        Me.tbSource.Size = New System.Drawing.Size(167, 20)
        Me.tbSource.TabIndex = 11
        Me.tbSource.Text = "EventLogVB Application"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(12, 13)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(59, 13)
        Me.label3.TabIndex = 10
        Me.label3.Text = "Log Name:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(12, 82)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(59, 13)
        Me.label2.TabIndex = 9
        Me.label2.Text = "Log Event:"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(12, 56)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(65, 13)
        Me.label1.TabIndex = 8
        Me.label1.Text = "Log Source:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(275, 168)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.tbEvent)
        Me.Controls.Add(Me.tbName)
        Me.Controls.Add(Me.tbSource)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Name = "Form1"
        Me.Text = "EventLogVB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents button2 As System.Windows.Forms.Button
    Private WithEvents button1 As System.Windows.Forms.Button
    Private WithEvents tbEvent As System.Windows.Forms.TextBox
    Private WithEvents tbName As System.Windows.Forms.TextBox
    Private WithEvents tbSource As System.Windows.Forms.TextBox
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label

End Class
