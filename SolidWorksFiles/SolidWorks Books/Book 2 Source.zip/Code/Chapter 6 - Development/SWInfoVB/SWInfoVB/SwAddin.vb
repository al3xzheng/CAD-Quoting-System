﻿Imports System.Runtime.InteropServices

Imports SldWorks
Imports SWPublished
Imports SwConst
Imports SwCommands

Imports SolidWorksTools
Imports SolidWorksTools.File

<Guid("B7F74A9B-5DF7-467e-87DC-8167CB8901EE"), ComVisible(True)> _
<SwAddin(Description:="Provide Live Information of active document/selection", Title:="SWInfo", LoadAtStartup:=True)> _
Public Class swAddin
    Implements SWPublished.SwAddin

    Dim iSwApp As SldWorks.SldWorks
    Dim iCmdMgr As SldWorks.CommandManager

    Dim myPMP As PMPInfo

#Region "Connection"
    Public Function ConnectToSW(ByVal ThisSW As Object, ByVal Cookie As Integer) As Boolean Implements SWPublished.ISwAddin.ConnectToSW
        iSwApp = ThisSW

        iSwApp.SetAddinCallbackInfo(0, Me, Cookie)

        iCmdMgr = iSwApp.GetCommandManager(Cookie)
        AddCommandMgr()

        AddEventHooks()

        ConnectToSW = True
    End Function
    Public Function DisconnectFromSW() As Boolean Implements SWPublished.ISwAddin.DisconnectFromSW
        RemovePMP()
        RemoveCommandMgr()
        RemoveEventHooks()

        iSwApp = Nothing
        GC.Collect()
        DisconnectFromSW = True
    End Function
#End Region

#Region "COM Registration"
    <ComRegisterFunction()> Public Shared Sub RegisterFunction(ByVal t As Type)

        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        Dim addinkey As Microsoft.Win32.RegistryKey = hklm.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 0)
        addinkey.SetValue("Description", "Provide Live Information of active document/selection")
        addinkey.SetValue("Title", "SWInfo")

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        addinkey = hkcu.CreateSubKey(keyname)
        addinkey.SetValue(Nothing, 1)
    End Sub
    <ComUnregisterFunction()> Public Shared Sub UnregisterFunction(ByVal t As Type)
        Dim hklm As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine
        Dim hkcu As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.CurrentUser

        Dim keyname As String = "SOFTWARE\SolidWorks\Addins\{" + t.GUID.ToString() + "}"
        hklm.DeleteSubKey(keyname)

        keyname = "Software\SolidWorks\AddInsStartup\{" + t.GUID.ToString() + "}"
        hkcu.DeleteSubKey(keyname)
    End Sub
#End Region

#Region "Command Manager2"
    Public Sub AddCommandMgr()
        Dim cmdGroup As CommandGroup

        cmdGroup = iCmdMgr.CreateCommandGroup(1, "SWInfo", "", "", 3)

        cmdGroup.AddCommandItem2("Launch SWInfo", 0, "", "", 0, "_cbCreatePMP", "", 0, swCommandItemType_e.swMenuItem Or swCommandItemType_e.swToolbarItem)

        cmdGroup.HasMenu = True
        cmdGroup.HasToolbar = True
        cmdGroup.Activate()
    End Sub

    Public Sub RemoveCommandMgr()
        iCmdMgr.RemoveCommandGroup(1)
    End Sub
#End Region

    Public Sub RemovePMP()
        myPMP = Nothing
    End Sub

    Public Sub _cbCreatePMP()
        myPMP = New PMPInfo(iSwApp)
        myPMP.ActiveModel = iSwApp.ActiveDoc
    End Sub

    Public Sub AddEventHooks()
        AddHandler iSwApp.ActiveModelDocChangeNotify, AddressOf iSwApp_ActiveModelDocChangeNotify
    End Sub

    Public Sub RemoveEventHooks()
        RemoveHandler iSwApp.ActiveModelDocChangeNotify, AddressOf iSwApp_ActiveModelDocChangeNotify
    End Sub

    Public Function iSwApp_ActiveModelDocChangeNotify() As Integer
        _cbCreatePMP()
        Return 0
    End Function

End Class

