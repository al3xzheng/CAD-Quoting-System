﻿Imports System.Runtime.InteropServices

Imports SldWorks
Imports SWPublished
Imports SwConst
Imports SwCommands

Imports SolidWorksTools
Imports SolidWorksTools.File

Public Class PMPInfo
    Implements PropertyManagerPage2Handler6

#Region "Properties"
    Private _activemod As SldWorks.ModelDoc2
    Public Property ActiveModel() As SldWorks.ModelDoc2
        Get
            Return _activemod
        End Get
        Set(ByVal value As SldWorks.ModelDoc2)
            _activemod = Value
            ActiveModelChanged()
        End Set
    End Property

    Public ReadOnly Property ActiveDrawing() As SldWorks.DrawingDoc
        Get
            Return ActiveModel
        End Get
    End Property
    Public ReadOnly Property ActivePart() As SldWorks.PartDoc
        Get
            Return ActiveModel
        End Get
    End Property
    Public ReadOnly Property ActiveAssembly() As SldWorks.AssemblyDoc
        Get
            Return ActiveModel
        End Get
    End Property
#End Region

#Region "Variables"
    Dim swApp As SldWorks.SldWorks
    Dim pmPage As PropertyManagerPage2
    Dim iErrors As Integer
    Public OK As Boolean

    ' Defaults
    Dim iStandardOption As Integer
    Dim iStandardGroupOption As Integer
    Dim iDisabledOption As Integer
    Dim sStandardAlign As Short

    Private _nid As Integer
    Public ReadOnly Property NextID()
        Get
            _nid += 1
            Return _nid
        End Get
    End Property

    Dim doctype As swDocumentTypes_e

    Dim selectedAsmModel As ModelDoc2
    Dim selectedDrawingView As View

    ' Keep track of combobox item counts
    Dim iDrawingSheetCount, iDrawingViewsCount As Integer


    Dim uidGroupDrawingInfo, _
        uidGroupPartInfo, _
        uidGroupAsmInfo, _
        uidGroupSheetInfo, _
        uidGroupViewInfo, _
        uidGroupCostInfo, _
        uidLabelFilename, _
        uidLabelSheets, _
        uidLabelTotalViews, _
        uidLabelViews, _
        uidLabelReferenceFile, _
        uidLabelReferenceConfig, _
        uidLabelOrientation, _
        uidLabelDisplayStyle, _
        uidLabelScale, _
        uidLabelTotalCost, _
        uidLabelPartCost, _
        uidLabelFeatCreatedBy, _
        uidLabelFeatCreateDate, _
        uidLabelFeatModifyDate, _
        uidTextboxFilename, _
        uidComboboxSheets, _
        uidNumboxTotalViews, _
        uidComboboxViews, _
        uidTextboxReferenceFile, _
        uidTextboxReferenceConfig, _
        uidTextboxOrientation, _
        uidTextboxDisplayStyle, _
        uidTextboxScale, _
        uidTextboxTotalCost, _
        uidButtonUpdateCost, _
        uidTextboxPartCost, _
        uidButtonSetPartCost, _
        uidTextboxFeatCreatedBy, _
        uidTextboxFeatCreateDate, _
        uidTextboxFeatModifyDate As Integer

    Dim ctrGroupDrawingInfo, _
        ctrGroupPartInfo, _
        ctrGroupAsmInfo, _
        ctrGroupSheetInfo, _
        ctrGroupViewInfo, _
        ctrGroupCostInfo As PropertyManagerPageGroup

    Dim ctrLabelFilename, _
        ctrLabelSheets, _
        ctrLabelTotalViews, _
        ctrLabelViews, _
        ctrLabelReferenceFile, _
        ctrLabelReferenceConfig, _
        ctrLabelOrientation, _
        ctrLabelDisplayStyle, _
        ctrLabelScale, _
        ctrLabelTotalCost, _
        ctrLabelPartCost, _
        ctrLabelFeatCreatedBy, _
        ctrLabelFeatCreateDate, _
        ctrLabelFeatModifyDate As PropertyManagerPageLabel

    Dim ctrTextboxFilename, _
        ctrTextboxReferenceFile, _
        ctrTextboxReferenceConfig, _
        ctrTextboxOrientation, _
        ctrTextboxDisplayStyle, _
        ctrTextboxScale, _
        ctrTextboxTotalCost, _
        ctrTextboxPartCost, _
        ctrTextboxFeatCreatedBy, _
        ctrTextboxFeatCreateDate, _
        ctrTextboxFeatModifyDate As PropertyManagerPageTextbox


    Dim ctrNumboxTotalViews As PropertyManagerPageNumberbox

    Dim ctrComboboxSheets, _
        ctrComboboxViews As PropertyManagerPageCombobox

    Dim ctrButtonUpdateCost, _
        ctrButtonSetPartCost As PropertyManagerPageButton
#End Region

#Region "Initialise"
    Public Sub New(ByVal app As SldWorks.SldWorks)
        swApp = app

        Try
            ' Create new PMP
            pmPage = app.CreatePropertyManagerPage("SwInfo", swPropertyManagerPageOptions_e.swPropertyManagerOptions_CloseDialogButton, Me, iErrors)

            ' Check if was created proeprly
            If iErrors <> swPropertyManagerPageStatus_e.swPropertyManagerPage_Okay Then
                swApp.SendMsgToUser2("Error creating PMP: " + CType(iErrors, swPropertyManagerPageStatus_e).ToString(), swMessageBoxIcon_e.swMbWarning, swMessageBoxBtn_e.swMbOk)
                OK = False
                Return
            End If

            OK = True
        Catch ex As Exception
            swApp.SendMsgToUser2("Error creating PMP: " + ex.Message, swMessageBoxIcon_e.swMbWarning, swMessageBoxBtn_e.swMbOk)
            OK = False
        End Try

        If OK Then AddControls()

    End Sub
#End Region

#Region "Create Controls"
    Private Sub SetIDs()
        _nid = 1

        uidGroupDrawingInfo = NextID
        uidGroupPartInfo = NextID
        uidGroupAsmInfo = NextID
        uidGroupSheetInfo = NextID
        uidGroupViewInfo = NextID
        uidGroupCostInfo = NextID

        uidLabelFilename = NextID
        uidLabelSheets = NextID
        uidLabelTotalViews = NextID
        uidLabelViews = NextID
        uidLabelReferenceFile = NextID
        uidLabelReferenceConfig = NextID
        uidLabelOrientation = NextID
        uidLabelDisplayStyle = NextID
        uidLabelScale = NextID
        uidLabelTotalCost = NextID
        uidLabelPartCost = NextID
        uidLabelFeatCreatedBy = NextID
        uidLabelFeatCreateDate = NextID
        uidLabelFeatModifyDate = NextID

        uidTextboxFilename = NextID
        uidComboboxSheets = NextID
        uidNumboxTotalViews = NextID
        uidComboboxViews = NextID
        uidTextboxReferenceFile = NextID
        uidTextboxReferenceConfig = NextID
        uidTextboxOrientation = NextID
        uidTextboxDisplayStyle = NextID
        uidTextboxScale = NextID

        uidTextboxTotalCost = NextID
        uidButtonUpdateCost = NextID
        uidTextboxPartCost = NextID
        uidButtonSetPartCost = NextID

        uidTextboxFeatCreatedBy = NextID
        uidTextboxFeatCreateDate = NextID
        uidTextboxFeatModifyDate = NextID
    End Sub

    Public Sub AddControls()
        pmPage.SetMessage3("Awaiting Initialisation", swPropertyManagerPageMessageVisibility.swImportantMessageBox, swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "SWInfo")

        iStandardOption = swAddControlOptions_e.swControlOptions_Enabled Or swAddControlOptions_e.swControlOptions_Visible
        iStandardGroupOption = swAddGroupBoxOptions_e.swGroupBoxOptions_Expanded Or swAddGroupBoxOptions_e.swGroupBoxOptions_Visible
        iDisabledOption = swAddControlOptions_e.swControlOptions_Visible
        sStandardAlign = swPropertyManagerPageControlLeftAlign_e.swControlAlign_LeftEdge

        SetIDs()

        ' DRAWING INFO GROUP
        ' ==============================
        ' Create group
        ctrGroupDrawingInfo = pmPage.AddGroupBox(uidGroupDrawingInfo, "Drawing Information", swAddGroupBoxOptions_e.swGroupBoxOptions_Expanded Or swAddGroupBoxOptions_e.swGroupBoxOptions_Visible)

        ' Filename
        ctrLabelFilename = CreateLabel(uidLabelFilename, "Filename", "", ctrGroupDrawingInfo)
        ctrTextboxFilename = CreateReadOnlyTextbox(uidTextboxFilename, "", "", ctrGroupDrawingInfo)

        ' SHEET INFO GROUP
        ' ==============================
        ctrGroupSheetInfo = pmPage.AddGroupBox(uidGroupSheetInfo, "Sheets", iStandardGroupOption)
        ' Sheets
        ctrLabelSheets = CreateLabel(uidLabelSheets, "Sheets", "", ctrGroupSheetInfo)
        ctrComboboxSheets = CreateCombobox(uidComboboxSheets, ctrGroupSheetInfo)

        ' Total Views
        ctrLabelTotalViews = CreateLabel(uidLabelTotalViews, "Total Views", "", ctrGroupSheetInfo)
        ctrNumboxTotalViews = CreateReadOnlyNumbox(uidNumboxTotalViews, ctrGroupSheetInfo)

        ' VIEW INFO GROUP
        ' ==============================
        ctrGroupViewInfo = pmPage.AddGroupBox(uidGroupViewInfo, "Views", iStandardGroupOption)
        ' Views
        ctrLabelViews = CreateLabel(uidLabelViews, "Views", "", ctrGroupViewInfo)
        ctrComboboxViews = CreateCombobox(uidComboboxViews, ctrGroupViewInfo)

        ' Referenced File
        ctrLabelReferenceFile = CreateLabel(uidLabelReferenceFile, "Referenced File", "", ctrGroupViewInfo)
        ctrTextboxReferenceFile = CreateReadOnlyTextbox(uidTextboxReferenceFile, "", "", ctrGroupViewInfo)

        ' Referenced Config
        ctrLabelReferenceConfig = CreateLabel(uidLabelReferenceConfig, "Referenced Config", "", ctrGroupViewInfo)
        ctrTextboxReferenceConfig = CreateReadOnlyTextbox(uidTextboxReferenceConfig, "", "", ctrGroupViewInfo)

        ' Orientation
        ctrLabelOrientation = CreateLabel(uidLabelOrientation, "Orientation", "", ctrGroupViewInfo)
        ctrTextboxOrientation = CreateReadOnlyTextbox(uidTextboxOrientation, "", "", ctrGroupViewInfo)

        ' Display Style
        ctrLabelDisplayStyle = CreateLabel(uidLabelDisplayStyle, "Display Style", "", ctrGroupViewInfo)
        ctrTextboxDisplayStyle = CreateReadOnlyTextbox(uidTextboxDisplayStyle, "", "", ctrGroupViewInfo)

        ' Scale
        ctrLabelScale = CreateLabel(uidLabelScale, "Scale", "", ctrGroupViewInfo)
        ctrTextboxScale = CreateReadOnlyTextbox(uidTextboxScale, "", "", ctrGroupViewInfo)


        ' PART INFO GROUP
        ' ==============================
        ctrGroupPartInfo = pmPage.AddGroupBox(uidGroupPartInfo, "Selected Feature Information", iStandardGroupOption)

        ' Created By
        ctrLabelFeatCreatedBy = CreateLabel(uidLabelFeatCreatedBy, "Created By", "", ctrGroupPartInfo)
        ctrTextboxFeatCreatedBy = CreateReadOnlyTextbox(uidTextboxFeatCreatedBy, "", "", ctrGroupPartInfo)

        ' Created Date
        ctrLabelFeatCreateDate = CreateLabel(uidLabelFeatCreateDate, "Creation Date", "", ctrGroupPartInfo)
        ctrTextboxFeatCreateDate = CreateReadOnlyTextbox(uidTextboxFeatCreateDate, "", "", ctrGroupPartInfo)

        ' Modify Date
        ctrLabelFeatModifyDate = CreateLabel(uidLabelFeatModifyDate, "Modify Date", "", ctrGroupPartInfo)
        ctrTextboxFeatModifyDate = CreateReadOnlyTextbox(uidTextboxFeatModifyDate, "", "", ctrGroupPartInfo)


        ' ASSEMBLY INFO GROUP
        ' ==============================
        ctrGroupAsmInfo = pmPage.AddGroupBox(uidGroupAsmInfo, "Assembly Information", iStandardGroupOption)

        ' Total Cost
        ctrLabelTotalCost = CreateLabel(uidLabelTotalCost, "Total Cost", "", ctrGroupAsmInfo)
        ctrTextboxTotalCost = CreateReadOnlyTextbox(uidTextboxTotalCost, "", "", ctrGroupAsmInfo)

        ' Update Cost
        ctrButtonUpdateCost = CreateButton(uidButtonUpdateCost, "Update Cost", "", ctrGroupAsmInfo)

        ' Selected part get/set cost
        ' ==============================
        ctrGroupCostInfo = pmPage.AddGroupBox(uidGroupCostInfo, "Cost Information", iStandardGroupOption)

        ' Part Cost
        ctrLabelPartCost = CreateLabel(uidLabelPartCost, "Part Cost", "", ctrGroupCostInfo)
        ctrTextboxPartCost = CreateTextbox(uidTextboxPartCost, "", "", ctrGroupCostInfo)

        ' Set Part Cost
        ctrButtonSetPartCost = CreateButton(uidButtonSetPartCost, "Set Cost", "", ctrGroupCostInfo)

    End Sub

    Private Function CreateButton(ByVal id As Integer, ByVal text As String, ByVal caption As String, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageButton
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Button, text, sStandardAlign, iStandardOption, caption)
    End Function
    Private Function CreateReadOnlyNumbox(ByVal id As Integer, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageNumberbox
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Numberbox, "", sStandardAlign, iDisabledOption, "")
    End Function
    Private Function CreateCombobox(ByVal id As Integer, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageCombobox
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Combobox, "", sStandardAlign, iStandardOption, "")
    End Function
    Private Function CreateTextbox(ByVal id As Integer, ByVal text As String, ByVal tip As String, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageTextbox
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Textbox, text, sStandardAlign, iStandardOption, tip)
    End Function
    Private Function CreateReadOnlyTextbox(ByVal id As Integer, ByVal text As String, ByVal tip As String, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageTextbox
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Textbox, text, sStandardAlign, iDisabledOption, tip)
    End Function
    Private Function CreateLabel(ByVal id As Integer, ByVal label As String, ByVal tip As String, ByVal parent As PropertyManagerPageGroup) As PropertyManagerPageLabel
        Return parent.AddControl(id, swPropertyManagerPageControlType_e.swControlType_Label, label, sStandardAlign, iStandardOption, tip)
    End Function
#End Region

#Region "Model Change / Toggle Functions"
    Private Sub ToggleView()
        Dim drawing, assembly, part As Boolean
        drawing = assembly = part = False
        If doctype = swDocumentTypes_e.swDocDRAWING Then drawing = True
        If doctype = swDocumentTypes_e.swDocASSEMBLY Then assembly = True
        If doctype = swDocumentTypes_e.swDocPART Then part = True

        ctrGroupDrawingInfo.Visible = drawing
        ctrGroupSheetInfo.Visible = drawing
        ctrGroupViewInfo.Visible = drawing

        ctrGroupPartInfo.Visible = part

        ctrGroupAsmInfo.Visible = assembly
        ctrGroupCostInfo.Visible = assembly
    End Sub

    ' Called by parent setting the ActiveDoc property
    Private Sub ActiveModelChanged()
        ' Check PMP was created successfully first
        If OK And Not ActiveModel Is Nothing Then
            doctype = ActiveModel.GetType()
            SetupModelHooks()
            InitialiseInformation()
            Show()
        End If
    End Sub

    Private Sub SetupModelHooks()
        Select Case doctype
            Case swDocumentTypes_e.swDocDRAWING
                AddHandler ActiveDrawing.NewSelectionNotify, AddressOf ActiveDrawing_NewSelectionNotify
            Case swDocumentTypes_e.swDocPART
                AddHandler ActivePart.NewSelectionNotify, AddressOf ActivePart_NewSelectionNotify
            Case swDocumentTypes_e.swDocASSEMBLY
                AddHandler ActiveAssembly.NewSelectionNotify, AddressOf ActiveAssembly_NewSelectionNotify
        End Select
    End Sub

    Private Sub InitialiseInformation()
        Select doctype
            Case swDocumentTypes_e.swDocDRAWING
                pmPage.SetMessage3("Select sheets or views to see additional information", swPropertyManagerPageMessageVisibility.swImportantMessageBox, swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Drawing Information")
                SetDrawingFilename()
                FillDrawingSheetList()
            Case swDocumentTypes_e.swDocPART
                pmPage.SetMessage3("Select features to show more details", swPropertyManagerPageMessageVisibility.swImportantMessageBox, swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Part Information")
            Case swDocumentTypes_e.swDocASSEMBLY
                pmPage.SetMessage3("Select components to see cost information", swPropertyManagerPageMessageVisibility.swImportantMessageBox, swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Drawing Information")
                CalculateAssemblyCost()
        End Select
    End Sub

#End Region

#Region "Hook Events"

    Private Function ActivePart_NewSelectionNotify() As Integer

        ' New selection made, get selected object
        ' Check if it is a feature
        Dim selmgr As SelectionMgr = ActiveModel.SelectionManager

        Dim feat As Feature
        Try
            ' This line will throw an exception and go to catch if selected object is not a feature
            feat = selmgr.GetSelectedObject6(1, -1)
            ctrTextboxFeatCreateDate.Text = feat.DateCreated
            ctrTextboxFeatCreatedBy.Text = feat.CreatedBy
            ctrTextboxFeatModifyDate.Text = feat.DateModified
        Catch
            Return 0
        End Try

        Return 0
    End Function

    Private Function ActiveAssembly_NewSelectionNotify() As Integer

        ' New selection made, get selected object
        ' Check if it is a component
        Dim selmgr As SelectionMgr = ActiveModel.SelectionManager
        Dim seltype As swSelectType_e = selmgr.GetSelectedObjectType3(1, -1)

        If seltype = swSelectType_e.swSelCOMPONENTS Then
            Dim com As Component2 = selmgr.GetSelectedObject6(1, -1)
            selectedAsmModel = com.GetModelDoc2()
            UpdateSelectedComponentCost(False)
        End If

        Return 0
    End Function

    Private Function ActiveDrawing_NewSelectionNotify() As Integer

        Dim SelMgr As SelectionMgr = ActiveModel.SelectionManager
        Dim type As swSelectType_e = SelMgr.GetSelectedObjectType3(1, -1)

        ' If new selection is a view
        If type = swSelectType_e.swSelDRAWINGVIEWS Then
            SelectComboboxItem(ctrComboboxViews, iDrawingViewsCount, SelMgr.GetSelectedObject6(1, -1).Name)
            selectedDrawingView = SelMgr.GetSelectedObject6(1, -1)
            DrawingViewSelectionChanged()
        End If

        Return 0
    End Function

#End Region

#Region "Reactive Functions"
    Private Sub CalculateAssemblyCost()
        ' Loop top level components
        Dim config As Configuration = ActiveModel.GetActiveConfiguration()
        Dim comps() As Object = config.GetRootComponent().GetChildren()

        If comps Is Nothing Then Return

        Dim runningtotal As Double = 0

        For Each comp As Component2 In comps
            ' Get cost from component
            Dim model As ModelDoc2 = comp.GetModelDoc2()
            If model Is Nothing Then Continue For

            Dim f As Double
            If Double.TryParse(model.GetCustomInfoValue("", "Cost"), f) Then runningtotal += f
        Next

        ctrTextboxTotalCost.Text = runningtotal.ToString()
    End Sub

    Private Sub UpdateSelectedComponentCost(ByVal setValue As Boolean)

        If setValue Then
            selectedAsmModel.DeleteCustomInfo2("", "Cost")
            selectedAsmModel.AddCustomInfo3("", "Cost", swCustomInfoType_e.swCustomInfoText, ctrTextboxPartCost.Text)
        Else
            ctrTextboxPartCost.Text = selectedAsmModel.GetCustomInfoValue("", "Cost")
        End If
    End Sub

    Private Sub DrawingViewSelectionChanged()
        If selectedDrawingView Is Nothing Then Return

        ctrTextboxReferenceFile.Text = selectedDrawingView.ReferencedDocument.GetPathName()
        ctrTextboxReferenceConfig.Text = selectedDrawingView.ReferencedConfiguration
        ctrTextboxOrientation.Text = selectedDrawingView.GetOrientationName()
        ctrTextboxDisplayStyle.Text = selectedDrawingView.GetDisplayMode2().ToString()
        Dim dRatio() As Double = selectedDrawingView.ScaleRatio
        ctrTextboxScale.Text = dRatio(0).ToString() + "/" + dRatio(1).ToString()
    End Sub

    Private Sub DrawingSheetSelectionChanged()
        FillDrawingViewList()
        ' Set Total Views
        ctrNumboxTotalViews.Value = iDrawingViewsCount
    End Sub

    Private Sub FillDrawingViewList()
        ' Fill list
        ' Get view count to keep track
        Dim views() As Object = ActiveDrawing.GetCurrentSheet().GetViews()

        ctrComboboxViews.Clear()
        ' If sheet has no views
        If views Is Nothing Or views.Length = 0 Then Return

        iDrawingViewsCount = views.Length
        For Each v As View In views
            ctrComboboxViews.AddItems(v.Name)
        Next

        ' Select first item if is one
        ctrComboboxViews.CurrentSelection = 0
        OnComboboxSelectionChanged(uidComboboxViews, 0)
    End Sub

    Private Sub SetDrawingFilename()
        ctrTextboxFilename.Text = System.IO.Path.GetFileName(ActiveModel.GetPathName())
    End Sub

    Private Sub FillDrawingSheetList()
        ' Fill list
        ' Get sheet count to keep track
        iDrawingSheetCount = ActiveDrawing.GetSheetCount()
        ctrComboboxSheets.Clear()
        ctrComboboxSheets.AddItems(ActiveDrawing.GetSheetNames())

        ' Select currently active sheet
        SelectComboboxItem(ctrComboboxSheets, iDrawingSheetCount, ActiveDrawing.GetCurrentSheet().GetName())
        DrawingSheetSelectionChanged()
    End Sub

#End Region

#Region "Generic Functions"
    Private Sub SelectComboboxItem(ByVal box As PropertyManagerPageCombobox, ByVal itemcount As Integer, ByVal name As String)
        For i As Short = 0 To itemcount - 1
            If box.get_ItemText(i) = name Then
                box.CurrentSelection = i
            End If
        Next
    End Sub
#End Region

    Public Sub Show()
        ToggleView()
        ' IMPORTANT! If you don't specify stacked show, will close on most events
        ' However, this appears to have bugs of its own causing the PMP to freeze in place and not close
        pmPage.Show2(swPropertyManagerPageShowOptions_e.swPropertyManagerShowOptions_StackPage)
    End Sub

    Public Sub OnButtonPress(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnButtonPress
        If Id = uidButtonSetPartCost Then
            UpdateSelectedComponentCost(True)
        ElseIf Id = uidButtonUpdateCost Then
            CalculateAssemblyCost()
        End If
    End Sub

    Public Sub OnComboboxSelectionChanged(ByVal Id As Integer, ByVal Item As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnComboboxSelectionChanged
        If Id = uidComboboxSheets Then
            ActiveDrawing.ActivateSheet(ctrComboboxSheets.ItemText(-1))
            DrawingSheetSelectionChanged()
        ElseIf Id = uidComboboxViews Then
            ActiveModel.Extension.SelectByID2(ctrComboboxViews.ItemText(-1), "DRAWINGVIEW", 0, 0, 0, False, -1, Nothing, 0)
        End If
    End Sub

    Public Sub AfterClose() Implements SWPublished.IPropertyManagerPage2Handler6.AfterClose
        _activemod = Nothing
        swApp = Nothing

        ctrGroupDrawingInfo = Nothing
        ctrGroupPartInfo = Nothing
        ctrGroupAsmInfo = Nothing
        ctrGroupSheetInfo = Nothing
        ctrGroupViewInfo = Nothing
        ctrGroupCostInfo = Nothing

        ctrLabelFilename = Nothing
        ctrLabelSheets = Nothing
        ctrLabelTotalViews = Nothing
        ctrLabelViews = Nothing
        ctrLabelReferenceFile = Nothing
        ctrLabelReferenceConfig = Nothing
        ctrLabelOrientation = Nothing
        ctrLabelDisplayStyle = Nothing
        ctrLabelScale = Nothing
        ctrLabelTotalCost = Nothing
        ctrLabelPartCost = Nothing
        ctrLabelFeatCreatedBy = Nothing
        ctrLabelFeatCreateDate = Nothing
        ctrLabelFeatModifyDate = Nothing

        ctrTextboxFilename = Nothing
        ctrTextboxReferenceFile = Nothing
        ctrTextboxReferenceConfig = Nothing
        ctrTextboxOrientation = Nothing
        ctrTextboxDisplayStyle = Nothing
        ctrTextboxScale = Nothing
        ctrTextboxTotalCost = Nothing
        ctrTextboxPartCost = Nothing
        ctrTextboxFeatCreatedBy = Nothing
        ctrTextboxFeatCreateDate = Nothing
        ctrTextboxFeatModifyDate = Nothing

        ctrNumboxTotalViews = Nothing

        ctrComboboxSheets = Nothing
        ctrComboboxViews = Nothing

        ctrButtonUpdateCost = Nothing
        ctrButtonSetPartCost = Nothing
        pmPage = Nothing
    End Sub

#Region "Default PMP Events"

    Public Sub AfterActivation() Implements SWPublished.IPropertyManagerPage2Handler6.AfterActivation

    End Sub

    Public Function OnActiveXControlCreated(ByVal Id As Integer, ByVal Status As Boolean) As Integer Implements SWPublished.IPropertyManagerPage2Handler6.OnActiveXControlCreated

    End Function

    Public Sub OnCheckboxCheck(ByVal Id As Integer, ByVal Checked As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnCheckboxCheck

    End Sub

    Public Sub OnClose(ByVal Reason As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnClose

    End Sub

    Public Sub OnComboboxEditChanged(ByVal Id As Integer, ByVal Text As String) Implements SWPublished.IPropertyManagerPage2Handler6.OnComboboxEditChanged

    End Sub

    Public Sub OnGroupCheck(ByVal Id As Integer, ByVal Checked As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnGroupCheck

    End Sub

    Public Sub OnGroupExpand(ByVal Id As Integer, ByVal Expanded As Boolean) Implements SWPublished.IPropertyManagerPage2Handler6.OnGroupExpand

    End Sub

    Public Function OnHelp() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnHelp

    End Function

    Public Function OnKeystroke(ByVal Wparam As Integer, ByVal Message As Integer, ByVal Lparam As Integer, ByVal Id As Integer) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnKeystroke

    End Function

    Public Sub OnListboxSelectionChanged(ByVal Id As Integer, ByVal Item As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnListboxSelectionChanged

    End Sub

    Public Function OnNextPage() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnNextPage

    End Function

    Public Sub OnNumberboxChanged(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnNumberboxChanged

    End Sub

    Public Sub OnOptionCheck(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnOptionCheck

    End Sub

    Public Sub OnPopupMenuItem(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnPopupMenuItem

    End Sub

    Public Sub OnPopupMenuItemUpdate(ByVal Id As Integer, ByRef retval As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnPopupMenuItemUpdate

    End Sub

    Public Function OnPreview() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnPreview

    End Function

    Public Function OnPreviousPage() As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnPreviousPage

    End Function

    Public Sub OnRedo() Implements SWPublished.IPropertyManagerPage2Handler6.OnRedo

    End Sub

    Public Sub OnSelectionboxCalloutCreated(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxCalloutCreated

    End Sub

    Public Sub OnSelectionboxCalloutDestroyed(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxCalloutDestroyed

    End Sub

    Public Sub OnSelectionboxFocusChanged(ByVal Id As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxFocusChanged

    End Sub

    Public Sub OnSelectionboxListChanged(ByVal Id As Integer, ByVal Count As Integer) Implements SWPublished.IPropertyManagerPage2Handler6.OnSelectionboxListChanged

    End Sub

    Public Sub OnSliderPositionChanged(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnSliderPositionChanged

    End Sub

    Public Sub OnSliderTrackingCompleted(ByVal Id As Integer, ByVal Value As Double) Implements SWPublished.IPropertyManagerPage2Handler6.OnSliderTrackingCompleted

    End Sub

    Public Function OnSubmitSelection(ByVal Id As Integer, ByVal Selection As Object, ByVal SelType As Integer, ByRef ItemText As String) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnSubmitSelection

    End Function

    Public Function OnTabClicked(ByVal Id As Integer) As Boolean Implements SWPublished.IPropertyManagerPage2Handler6.OnTabClicked

    End Function

    Public Sub OnTextboxChanged(ByVal Id As Integer, ByVal Text As String) Implements SWPublished.IPropertyManagerPage2Handler6.OnTextboxChanged

    End Sub

    Public Sub OnUndo() Implements SWPublished.IPropertyManagerPage2Handler6.OnUndo

    End Sub

    Public Sub OnWhatsNew() Implements SWPublished.IPropertyManagerPage2Handler6.OnWhatsNew

    End Sub

#End Region
End Class
