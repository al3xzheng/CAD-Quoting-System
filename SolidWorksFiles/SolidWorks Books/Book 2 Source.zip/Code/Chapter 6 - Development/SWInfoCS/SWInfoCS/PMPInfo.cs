﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

using SldWorks;
using SWPublished;
using SwConst;
using SwCommands;

using SolidWorksTools;
using SolidWorksTools.File;

namespace SWInfoCS
{
    public class PMPInfo : IPropertyManagerPage2Handler6
    {
        #region Properties
        private SldWorks.ModelDoc2 _activemod;
        public SldWorks.ModelDoc2 ActiveModel
        {
            get
            {
                return _activemod;
            }

            set
            {
                _activemod = value;
                ActiveModelChanged();
            }
        }

        public SldWorks.DrawingDoc ActiveDrawing { get { return (DrawingDoc)ActiveModel; } }
        public SldWorks.PartDoc ActivePart { get { return (PartDoc)ActiveModel; } }
        public SldWorks.AssemblyDoc ActiveAssembly { get { return (AssemblyDoc)ActiveModel; } }
        #endregion Properties

        #region Variables
        SldWorks.SldWorks swApp;
        IPropertyManagerPage2 pmPage;
        int iErrors;
        public bool OK;

        // Defaults
        int iStandardOption;
        int iStandardGroupOption;
        int iDisabledOption;
        short sStandardAlign;

        private int _nid;
        public int NextID { get { return _nid++; } }

        swDocumentTypes_e doctype;

        ModelDoc2 selectedAsmModel;
        View selectedDrawingView;

        // Keep track of combobox item counts
        int iDrawingSheetCount, iDrawingViewsCount;
        
        int uidGroupDrawingInfo,
            uidGroupPartInfo,
            uidGroupAsmInfo,
            uidGroupSheetInfo,
            uidGroupViewInfo,
            uidGroupCostInfo,
            
            uidLabelFilename,
            uidLabelSheets,
            uidLabelTotalViews,
            uidLabelViews,
            uidLabelReferenceFile,
            uidLabelReferenceConfig,
            uidLabelOrientation,
            uidLabelDisplayStyle,
            uidLabelScale,
            uidLabelTotalCost,
            uidLabelPartCost,
            uidLabelFeatCreatedBy,
            uidLabelFeatCreateDate,
            uidLabelFeatModifyDate,

            uidTextboxFilename,
            uidComboboxSheets,
            uidNumboxTotalViews,
            uidComboboxViews,
            uidTextboxReferenceFile,
            uidTextboxReferenceConfig,
            uidTextboxOrientation,
            uidTextboxDisplayStyle,
            uidTextboxScale,
            
            uidTextboxTotalCost,
            uidButtonUpdateCost,
            uidTextboxPartCost,
            uidButtonSetPartCost,

            uidTextboxFeatCreatedBy,
            uidTextboxFeatCreateDate,
            uidTextboxFeatModifyDate;

        PropertyManagerPageGroup    ctrGroupDrawingInfo,
                                    ctrGroupPartInfo,
                                    ctrGroupAsmInfo,
                                    ctrGroupSheetInfo,
                                    ctrGroupViewInfo,
                                    ctrGroupCostInfo;

        PropertyManagerPageLabel    ctrLabelFilename,
                                    ctrLabelSheets,
                                    ctrLabelTotalViews,
                                    ctrLabelViews,
                                    ctrLabelReferenceFile,
                                    ctrLabelReferenceConfig,
                                    ctrLabelOrientation,
                                    ctrLabelDisplayStyle,
                                    ctrLabelScale,
                                    ctrLabelTotalCost,
                                    ctrLabelPartCost,
                                    ctrLabelFeatCreatedBy,
                                    ctrLabelFeatCreateDate,
                                    ctrLabelFeatModifyDate;
        
        PropertyManagerPageTextbox  ctrTextboxFilename,
                                    ctrTextboxReferenceFile,
                                    ctrTextboxReferenceConfig,
                                    ctrTextboxOrientation,
                                    ctrTextboxDisplayStyle,
                                    ctrTextboxScale,
                                    ctrTextboxTotalCost,
                                    ctrTextboxPartCost,
                                    ctrTextboxFeatCreatedBy,
                                    ctrTextboxFeatCreateDate,
                                    ctrTextboxFeatModifyDate;


        PropertyManagerPageNumberbox ctrNumboxTotalViews;

        PropertyManagerPageCombobox ctrComboboxSheets,
                                    ctrComboboxViews;

        PropertyManagerPageButton   ctrButtonUpdateCost,
                                    ctrButtonSetPartCost;
        #endregion Variables

        #region Initialise
        public PMPInfo(SldWorks.SldWorks app)
        {
            swApp = app;

            CreatePMP();
        }

        private void CreatePMP()
        {
            try
            {
                // Create new page
                pmPage = (IPropertyManagerPage2)swApp.CreatePropertyManagerPage("SwInfo", (int)(swPropertyManagerPageOptions_e.swPropertyManagerOptions_CloseDialogButton), this, ref iErrors);

                // Check if was created proeprly
                if (iErrors != (int)swPropertyManagerPageStatus_e.swPropertyManagerPage_Okay)
                {
                    swApp.SendMsgToUser2("Error creating PMP: " + ((swPropertyManagerPageStatus_e)iErrors).ToString(), (int)swMessageBoxIcon_e.swMbWarning, (int)swMessageBoxBtn_e.swMbOk);
                    OK = false;
                    return;
                }

                OK = true;
            }
            catch (Exception e)
            {
                swApp.SendMsgToUser2("Error creating PMP: " + e.Message, (int)swMessageBoxIcon_e.swMbWarning, (int)swMessageBoxBtn_e.swMbOk);
                OK = false;
            }

            if (OK)
                AddControls();
        }

        #endregion Initialise

        #region Create Controls
        private void SetIDs()
        {
            _nid = 1;

            uidGroupDrawingInfo = NextID;
            uidGroupPartInfo = NextID;
            uidGroupAsmInfo = NextID;
            uidGroupSheetInfo = NextID;
            uidGroupViewInfo = NextID;
            uidGroupCostInfo = NextID;

            uidLabelFilename = NextID;
            uidLabelSheets = NextID;
            uidLabelTotalViews = NextID;
            uidLabelViews = NextID;
            uidLabelReferenceFile = NextID;
            uidLabelReferenceConfig = NextID;
            uidLabelOrientation = NextID;
            uidLabelDisplayStyle = NextID;
            uidLabelScale = NextID;
            uidLabelTotalCost = NextID;
            uidLabelPartCost = NextID;
            uidLabelFeatCreatedBy = NextID;
            uidLabelFeatCreateDate = NextID;
            uidLabelFeatModifyDate = NextID;

            uidTextboxFilename = NextID;
            uidComboboxSheets = NextID;
            uidNumboxTotalViews = NextID;
            uidComboboxViews = NextID;
            uidTextboxReferenceFile = NextID;
            uidTextboxReferenceConfig = NextID;
            uidTextboxOrientation = NextID;
            uidTextboxDisplayStyle = NextID;
            uidTextboxScale = NextID;

            uidTextboxTotalCost = NextID;
            uidButtonUpdateCost = NextID;
            uidTextboxPartCost = NextID;
            uidButtonSetPartCost = NextID;

            uidTextboxFeatCreatedBy = NextID;
            uidTextboxFeatCreateDate = NextID;
            uidTextboxFeatModifyDate = NextID;
        }
        private void AddControls()
        {
            pmPage.SetMessage3("Awaiting Initialisation", (int)swPropertyManagerPageMessageVisibility.swImportantMessageBox, (int)swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "SWInfo");

            iStandardOption = (int)(swAddControlOptions_e.swControlOptions_Enabled | swAddControlOptions_e.swControlOptions_Visible);
            iStandardGroupOption = (int)(swAddGroupBoxOptions_e.swGroupBoxOptions_Expanded | swAddGroupBoxOptions_e.swGroupBoxOptions_Visible);
            iDisabledOption = (int)swAddControlOptions_e.swControlOptions_Visible;
            sStandardAlign = (short)swPropertyManagerPageControlLeftAlign_e.swControlAlign_LeftEdge;

            SetIDs();

            #region Drawing Group
            // DRAWING INFO GROUP
            // ==============================
            // Create group
            ctrGroupDrawingInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupDrawingInfo, "Drawing Information", (int)(swAddGroupBoxOptions_e.swGroupBoxOptions_Expanded | swAddGroupBoxOptions_e.swGroupBoxOptions_Visible));

            // Filename
            ctrLabelFilename = CreateLabel(uidLabelFilename, "Filename", "", ctrGroupDrawingInfo);
            ctrTextboxFilename = CreateReadOnlyTextbox(uidTextboxFilename, "", "", ctrGroupDrawingInfo);

            // SHEET INFO GROUP
            // ==============================
            ctrGroupSheetInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupSheetInfo, "Sheets", iStandardGroupOption);
            // Sheets
            ctrLabelSheets = CreateLabel(uidLabelSheets, "Sheets", "", ctrGroupSheetInfo);
            ctrComboboxSheets = CreateCombobox(uidComboboxSheets, ctrGroupSheetInfo);

            // Total Views
            ctrLabelTotalViews = CreateLabel(uidLabelTotalViews, "Total Views", "", ctrGroupSheetInfo);
            ctrNumboxTotalViews = CreateReadOnlyNumbox(uidNumboxTotalViews, ctrGroupSheetInfo);

            // VIEW INFO GROUP
            // ==============================
            ctrGroupViewInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupViewInfo, "Views", iStandardGroupOption);
            // Views
            ctrLabelViews = CreateLabel(uidLabelViews, "Views", "", ctrGroupViewInfo);
            ctrComboboxViews = CreateCombobox(uidComboboxViews, ctrGroupViewInfo);

            // Referenced File
            ctrLabelReferenceFile = CreateLabel(uidLabelReferenceFile, "Referenced File", "", ctrGroupViewInfo);
            ctrTextboxReferenceFile = CreateReadOnlyTextbox(uidTextboxReferenceFile, "", "", ctrGroupViewInfo);

            // Referenced Config
            ctrLabelReferenceConfig = CreateLabel(uidLabelReferenceConfig, "Referenced Config", "", ctrGroupViewInfo);
            ctrTextboxReferenceConfig = CreateReadOnlyTextbox(uidTextboxReferenceConfig, "", "", ctrGroupViewInfo);

            // Orientation
            ctrLabelOrientation = CreateLabel(uidLabelOrientation, "Orientation", "", ctrGroupViewInfo);
            ctrTextboxOrientation = CreateReadOnlyTextbox(uidTextboxOrientation, "", "", ctrGroupViewInfo);

            // Display Style
            ctrLabelDisplayStyle = CreateLabel(uidLabelDisplayStyle, "Display Style", "", ctrGroupViewInfo);
            ctrTextboxDisplayStyle = CreateReadOnlyTextbox(uidTextboxDisplayStyle, "", "", ctrGroupViewInfo);

            // Scale
            ctrLabelScale = CreateLabel(uidLabelScale, "Scale", "", ctrGroupViewInfo);
            ctrTextboxScale = CreateReadOnlyTextbox(uidTextboxScale, "", "", ctrGroupViewInfo);

            #endregion Drawing Group

            #region Part Group
            // ==============================
            ctrGroupPartInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupPartInfo, "Selected Feature Information", iStandardGroupOption);

            // Created By
            ctrLabelFeatCreatedBy = CreateLabel(uidLabelFeatCreatedBy, "Created By", "", ctrGroupPartInfo);
            ctrTextboxFeatCreatedBy = CreateReadOnlyTextbox(uidTextboxFeatCreatedBy, "", "", ctrGroupPartInfo);

            // Created Date
            ctrLabelFeatCreateDate = CreateLabel(uidLabelFeatCreateDate, "Creation Date", "", ctrGroupPartInfo);
            ctrTextboxFeatCreateDate = CreateReadOnlyTextbox(uidTextboxFeatCreateDate, "", "", ctrGroupPartInfo);

            // Modify Date
            ctrLabelFeatModifyDate = CreateLabel(uidLabelFeatModifyDate, "Modify Date", "", ctrGroupPartInfo);
            ctrTextboxFeatModifyDate = CreateReadOnlyTextbox(uidTextboxFeatModifyDate, "", "", ctrGroupPartInfo);

            #endregion Part Group

            #region Assembly Group
            // ==============================
            ctrGroupAsmInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupAsmInfo, "Assembly Information", iStandardGroupOption);

            // Total Cost
            ctrLabelTotalCost = CreateLabel(uidLabelTotalCost, "Total Cost", "", ctrGroupAsmInfo);
            ctrTextboxTotalCost = CreateReadOnlyTextbox(uidTextboxTotalCost, "", "", ctrGroupAsmInfo);

            // Update Cost
            ctrButtonUpdateCost = CreateButton(uidButtonUpdateCost, "Update Cost", "", ctrGroupAsmInfo);

            // Selected part get/set cost
            // ==============================
            ctrGroupCostInfo = (PropertyManagerPageGroup)pmPage.AddGroupBox(uidGroupCostInfo, "Cost Information", iStandardGroupOption);

            // Part Cost
            ctrLabelPartCost = CreateLabel(uidLabelPartCost, "Part Cost", "", ctrGroupCostInfo);
            ctrTextboxPartCost = CreateTextbox(uidTextboxPartCost, "", "", ctrGroupCostInfo);

            // Set Part Cost
            ctrButtonSetPartCost = CreateButton(uidButtonSetPartCost, "Set Cost", "", ctrGroupCostInfo);

            #endregion Assembly Group
        }

        private PropertyManagerPageButton CreateButton(int id, string text, string caption, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageButton)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Button, text, sStandardAlign, iStandardOption, caption);
        }
        private PropertyManagerPageNumberbox CreateReadOnlyNumbox(int id, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageNumberbox)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Numberbox, "", sStandardAlign, iDisabledOption, "");
        }
        private PropertyManagerPageCombobox CreateCombobox(int id, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageCombobox)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Combobox, "", sStandardAlign, iStandardOption, "");
        }
        private PropertyManagerPageTextbox CreateTextbox(int id, string text, string tip, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageTextbox)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Textbox, text, sStandardAlign, iStandardOption, tip);
        }
        private PropertyManagerPageTextbox CreateReadOnlyTextbox(int id, string text, string tip, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageTextbox)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Textbox, text, sStandardAlign, iDisabledOption, tip);
        }
        private PropertyManagerPageLabel CreateLabel(int id, string label, string tip, PropertyManagerPageGroup parent)
        {
            return (PropertyManagerPageLabel)parent.AddControl(id, (short)swPropertyManagerPageControlType_e.swControlType_Label, label, sStandardAlign, iStandardOption, tip);
        }
        #endregion Create Controls

        #region Model Change / Toggle Functions
        // Called by parent setting the ActiveDoc property
        private void ActiveModelChanged()
        {
            // Check PMP was created successfully first
            if (OK && ActiveModel != null)
            {
                doctype = (swDocumentTypes_e)ActiveModel.GetType();
                SetupModelHooks();
                InitialiseInformation();
                Show();
            }
        }
        private void ToggleView()
        {
            bool drawing, assembly, part;
            drawing = doctype == swDocumentTypes_e.swDocDRAWING;
            assembly = doctype == swDocumentTypes_e.swDocASSEMBLY;
            part = doctype == swDocumentTypes_e.swDocPART;

            ctrGroupDrawingInfo.Visible = drawing;
            ctrGroupSheetInfo.Visible = drawing;
            ctrGroupViewInfo.Visible = drawing;

            ctrGroupPartInfo.Visible = part;

            ctrGroupAsmInfo.Visible = assembly;
            ctrGroupCostInfo.Visible = assembly;
        }
        private void SetupModelHooks()
        {
            switch (doctype)
            {
                case swDocumentTypes_e.swDocDRAWING:
                    ActiveDrawing.NewSelectionNotify += new DDrawingDocEvents_NewSelectionNotifyEventHandler(ActiveDrawing_NewSelectionNotify);
                    break;
                case swDocumentTypes_e.swDocPART:
                    ActivePart.NewSelectionNotify += new DPartDocEvents_NewSelectionNotifyEventHandler(ActivePart_NewSelectionNotify);
                    break;

                case swDocumentTypes_e.swDocASSEMBLY:
                    ActiveAssembly.NewSelectionNotify += new DAssemblyDocEvents_NewSelectionNotifyEventHandler(ActiveAssembly_NewSelectionNotify);
                    break;

            }
        }
        private void InitialiseInformation()
        {
            switch (doctype)
            {
                case swDocumentTypes_e.swDocDRAWING:
                    pmPage.SetMessage3("Select sheets or views to see additional information", (int)swPropertyManagerPageMessageVisibility.swImportantMessageBox, (int)swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Drawing Information");
                    SetDrawingFilename();
                    FillDrawingSheetList();
                    break;
                case swDocumentTypes_e.swDocPART:
                    pmPage.SetMessage3("Select features to show more details", (int)swPropertyManagerPageMessageVisibility.swImportantMessageBox, (int)swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Part Information");

                    break;

                case swDocumentTypes_e.swDocASSEMBLY:
                    pmPage.SetMessage3("Select components to see cost information", (int)swPropertyManagerPageMessageVisibility.swImportantMessageBox, (int)swPropertyManagerPageMessageExpanded.swMessageBoxMaintainExpandState, "Drawing Information");
                    CalculateAssemblyCost();
                    break;

            }
        }
        #endregion Model Change / Toggle Functions

        #region Hook Events
        int ActiveAssembly_NewSelectionNotify()
        {
            // New selection made, get selected object
            // Check if it is a component
            SelectionMgr selmgr = (SelectionMgr)ActiveModel.SelectionManager;
            swSelectType_e seltype = (swSelectType_e)selmgr.GetSelectedObjectType3(1, -1);

            if (seltype == swSelectType_e.swSelCOMPONENTS)
            {
                Component2 com = (Component2)selmgr.GetSelectedObject6(1, -1);
                selectedAsmModel = (ModelDoc2)com.GetModelDoc2();
                UpdateSelectedComponentCost(false);
            }

            return 0;
        }
        int ActivePart_NewSelectionNotify()
        {
            // New selection made, get selected object
            // Check if it is a feature
            SelectionMgr selmgr = (SelectionMgr)ActiveModel.SelectionManager;

            Feature feat;
            try
            {
                // This line will throw an exception and go to catch if selected object is not a feature
                feat = (Feature)selmgr.GetSelectedObject6(1, -1);
                ctrTextboxFeatCreateDate.Text = feat.DateCreated;
                ctrTextboxFeatCreatedBy.Text = feat.CreatedBy;
                ctrTextboxFeatModifyDate.Text = feat.DateModified;
            }
            catch { return 0; }

            return 0;
        }
        int ActiveDrawing_NewSelectionNotify()
        {
            SelectionMgr SelMgr = (SelectionMgr)ActiveModel.SelectionManager;
            swSelectType_e type = (swSelectType_e)SelMgr.GetSelectedObjectType3(1, -1);

            // If new selection is a view
            if (type == swSelectType_e.swSelDRAWINGVIEWS)
            {
                SelectComboboxItem(ctrComboboxViews, iDrawingViewsCount, ((View)SelMgr.GetSelectedObject6(1, -1)).Name);
                selectedDrawingView = (View)SelMgr.GetSelectedObject6(1, -1);
                DrawingViewSelectionChanged();
            }

            return 0;
        }
        #endregion Hook Events

        #region Reactive Functions
        #region Assembly
        private void CalculateAssemblyCost()
        {
            // Loop top level components
            Configuration config = (Configuration)ActiveModel.GetActiveConfiguration();
            object[] comps = (object[])((Component2)config.GetRootComponent()).GetChildren();

            if (comps == null)
                return;

            float runningtotal = 0;

            foreach (Component2 comp in comps)
            {
                // Get cost from component
                ModelDoc2 mod = (ModelDoc2)comp.GetModelDoc2();
                if (mod == null)
                    continue;

                float f;
                if (float.TryParse(mod.get_CustomInfo2("", "Cost"), out f))
                    runningtotal += f;                
            }

            ctrTextboxTotalCost.Text = runningtotal.ToString();
        }
        private void UpdateSelectedComponentCost(bool set)
        {
            if (set)
            {
                selectedAsmModel.DeleteCustomInfo2("", "Cost");
                selectedAsmModel.AddCustomInfo3("", "Cost", (int)swCustomInfoType_e.swCustomInfoText, ctrTextboxPartCost.Text);
            }
            else
                ctrTextboxPartCost.Text = selectedAsmModel.get_CustomInfo2("", "Cost");
        }
        #endregion Assembly

        #region Drawing
        private void SetDrawingFilename()
        {
            ctrTextboxFilename.Text = System.IO.Path.GetFileName(ActiveModel.GetPathName());
        }
        private void FillDrawingSheetList()
        {
            // Fill list
            // Get sheet count to keep track
            iDrawingSheetCount = ActiveDrawing.GetSheetCount();
            ctrComboboxSheets.Clear();
            ctrComboboxSheets.AddItems(ActiveDrawing.GetSheetNames());
            
            // Select currently active sheet
            SelectComboboxItem(ctrComboboxSheets, iDrawingSheetCount, ((Sheet)ActiveDrawing.GetCurrentSheet()).GetName());
            DrawingSheetSelectionChanged();
        }

        private void FillDrawingViewList()
        {
            // Fill list
            // Get view count to keep track
            object[] views = (object[])((Sheet)ActiveDrawing.GetCurrentSheet()).GetViews();

            ctrComboboxViews.Clear();
            // If sheet has no views
            if (views == null || views.Length == 0)
                return;

            iDrawingViewsCount = views.Length;
            foreach (View v in views)
                ctrComboboxViews.AddItems(v.Name);

            // Select first item if is one
            ctrComboboxViews.CurrentSelection = 0;
            OnComboboxSelectionChanged(uidComboboxViews,0);
        }

        private void DrawingSheetSelectionChanged()
        {
            FillDrawingViewList();
            // Set Total Views
            ctrNumboxTotalViews.Value = iDrawingViewsCount;
        }
        private void DrawingViewSelectionChanged()
        {
            if (selectedDrawingView == null)
                return;

            ctrTextboxReferenceFile.Text = selectedDrawingView.ReferencedDocument.GetPathName();
            ctrTextboxReferenceConfig.Text = selectedDrawingView.ReferencedConfiguration;
            ctrTextboxOrientation.Text = selectedDrawingView.GetOrientationName();
            ctrTextboxDisplayStyle.Text = ((swDisplayMode_e)selectedDrawingView.GetDisplayMode2()).ToString();
            double[] dRatio = (double[])selectedDrawingView.ScaleRatio;
            ctrTextboxScale.Text = dRatio[0].ToString() + "/" + dRatio[1].ToString();
        }
        #endregion Drawing
        #endregion Reactive Functions

        #region Generic Functions
        private void SelectComboboxItem(PropertyManagerPageCombobox box, int itemcount, string name)
        {
            short i;
            for (i = 0; i < itemcount; i++)
                if (box.get_ItemText(i) == name)
                    box.CurrentSelection = i;
        }
        #endregion Generic Functions

        public void Show()
        {
            ToggleView();
            // IMPORTANT! If you don't specify stacked show, will close on most events
            pmPage.Show2((int)swPropertyManagerPageShowOptions_e.swPropertyManagerShowOptions_StackPage); // pmPage.Show2(0);
        }

        public void OnButtonPress(int Id)
        {
            if (Id == uidButtonSetPartCost)
                UpdateSelectedComponentCost(true);
            else if (Id == uidButtonUpdateCost)
                CalculateAssemblyCost();
        }
        // This is only called if user changes it, not programatically
        public void OnComboboxSelectionChanged(int Id, int Item)
        {
            if (Id == uidComboboxSheets)
            {
                ActiveDrawing.ActivateSheet(ctrComboboxSheets.get_ItemText(-1));
                DrawingSheetSelectionChanged();
            }
            else if (Id == uidComboboxViews)
                ActiveModel.Extension.SelectByID2(ctrComboboxViews.get_ItemText(-1), "DRAWINGVIEW", 0, 0, 0, false, -1, null, 0);
        }

        public void AfterClose()
        {
            _activemod = null;
            swApp = null;

            ctrGroupDrawingInfo = null;
            ctrGroupPartInfo = null;
            ctrGroupAsmInfo = null;
            ctrGroupSheetInfo = null;
            ctrGroupViewInfo = null;
            ctrGroupCostInfo = null;

            ctrLabelFilename = null;
            ctrLabelSheets = null;
            ctrLabelTotalViews = null;
            ctrLabelViews = null;
            ctrLabelReferenceFile = null;
            ctrLabelReferenceConfig = null;
            ctrLabelOrientation = null;
            ctrLabelDisplayStyle = null;
            ctrLabelScale = null;
            ctrLabelTotalCost = null;
            ctrLabelPartCost = null;
            ctrLabelFeatCreatedBy = null;
            ctrLabelFeatCreateDate = null;
            ctrLabelFeatModifyDate = null;

            ctrTextboxFilename = null;
            ctrTextboxReferenceFile = null;
            ctrTextboxReferenceConfig = null;
            ctrTextboxOrientation = null;
            ctrTextboxDisplayStyle = null;
            ctrTextboxScale = null;
            ctrTextboxTotalCost = null;
            ctrTextboxPartCost = null;
            ctrTextboxFeatCreatedBy = null;
            ctrTextboxFeatCreateDate = null;
            ctrTextboxFeatModifyDate = null;


            ctrNumboxTotalViews = null;

            ctrComboboxSheets = null;
            ctrComboboxViews = null;

            ctrButtonUpdateCost = null;
            ctrButtonSetPartCost = null;

            pmPage = null;
        }

        #region Default PMP Members

        public void AfterActivation()
        {

        }

        public int OnActiveXControlCreated(int Id, bool Status)
        {
            return 0;
        }

        public void OnCheckboxCheck(int Id, bool Checked)
        {

        }

        public void OnClose(int Reason)
        {

        }

        public void OnComboboxEditChanged(int Id, string Text)
        {

        }

        public void OnGroupCheck(int Id, bool Checked)
        {

        }

        public void OnGroupExpand(int Id, bool Expanded)
        {

        }

        public bool OnHelp()
        {
            return false;
        }

        public bool OnKeystroke(int Wparam, int Message, int Lparam, int Id)
        {
            return false;
        }

        public void OnListboxSelectionChanged(int Id, int Item)
        {

        }

        public bool OnNextPage()
        {
            return false;
        }

        public void OnNumberboxChanged(int Id, double Value)
        {

        }

        public void OnOptionCheck(int Id)
        {

        }

        public void OnPopupMenuItem(int Id)
        {

        }

        public void OnPopupMenuItemUpdate(int Id, ref int retval)
        {

        }

        public bool OnPreview()
        {
            return false;
        }

        public bool OnPreviousPage()
        {
            return false;
        }

        public void OnRedo()
        {

        }

        public void OnSelectionboxCalloutCreated(int Id)
        {

        }

        public void OnSelectionboxCalloutDestroyed(int Id)
        {

        }

        public void OnSelectionboxFocusChanged(int Id)
        {

        }

        public void OnSelectionboxListChanged(int Id, int Count)
        {

        }

        public void OnSliderPositionChanged(int Id, double Value)
        {

        }

        public void OnSliderTrackingCompleted(int Id, double Value)
        {

        }

        public bool OnSubmitSelection(int Id, object Selection, int SelType, ref string ItemText)
        {
            return false;
        }

        public bool OnTabClicked(int Id)
        {
            return false;
        }

        public void OnTextboxChanged(int Id, string Text)
        {

        }

        public void OnUndo()
        {

        }

        public void OnWhatsNew()
        {

        }

        #endregion
    }
}
