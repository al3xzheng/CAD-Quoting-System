﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

using SldWorks;
using SWPublished;
using SwConst;
using SwCommands;

using SolidWorksTools;
using SolidWorksTools.File;

namespace SWInfoCS
{
    [Guid("B7F74A9B-5DF7-467e-87DC-8167CB8901EE"), ComVisible(true)]
    [SwAddin(Description = "Provide Live Information of active document/selection", Title = "SWInfo", LoadAtStartup = true)]
    public class swAddin : ISwAddin
    {
        SldWorks.SldWorks iSwApp;
        ICommandManager iCmdMgr;
        PMPInfo myPMP;

        #region Connection
        public bool ConnectToSW(object ThisSW, int Cookie)
        {
            iSwApp = (SldWorks.SldWorks)ThisSW;

            iSwApp.SetAddinCallbackInfo(0, this, Cookie);

            iCmdMgr = iSwApp.GetCommandManager(Cookie);
            AddCommandMgr();

            AddEventHooks();

            return true;
        }

        public bool DisconnectFromSW()
        {
            RemoveCommandMgr();
            RemovePMP();
            RemoveEventHooks();

            iSwApp = null;
            GC.Collect();
            return true;
        }

        #endregion Connection

        #region COM Registration
        [ComRegisterFunctionAttribute]
        public static void RegisterFunction(Type t)
        {
            Microsoft.Win32.RegistryKey hklm = Microsoft.Win32.Registry.LocalMachine;
            Microsoft.Win32.RegistryKey hkcu = Microsoft.Win32.Registry.CurrentUser;

            string keyname = "SOFTWARE\\SolidWorks\\Addins\\{" + t.GUID.ToString() + "}";
            Microsoft.Win32.RegistryKey addinkey = hklm.CreateSubKey(keyname);
            addinkey.SetValue(null, 0);
            addinkey.SetValue("Description", "Provide Live Information of active document/selection");
            addinkey.SetValue("Title", "SWInfo");

            keyname = "Software\\SolidWorks\\AddInsStartup\\{" + t.GUID.ToString() + "}";
            addinkey = hkcu.CreateSubKey(keyname);
            addinkey.SetValue(null, 1);
        }

        [ComUnregisterFunctionAttribute]
        public static void UnregisterFunction(Type t)
        {
            //Insert code here.
            Microsoft.Win32.RegistryKey hklm = Microsoft.Win32.Registry.LocalMachine;
            Microsoft.Win32.RegistryKey hkcu = Microsoft.Win32.Registry.CurrentUser;

            string keyname = "SOFTWARE\\SolidWorks\\Addins\\{" + t.GUID.ToString() + "}";
            hklm.DeleteSubKey(keyname);

            keyname = "Software\\SolidWorks\\AddInsStartup\\{" + t.GUID.ToString() + "}";
            hkcu.DeleteSubKey(keyname);
        }
        #endregion COM Registration

        #region Command Manager
        public void AddCommandMgr()
        {
            ICommandGroup cmdGroup;

            cmdGroup = iCmdMgr.CreateCommandGroup(1, "SWInfo", "", "", 3);

            cmdGroup.AddCommandItem2("Launch SWInfo", 0, "", "", 0, "_cbCreatePMP", "", 0, (int)(swCommandItemType_e.swMenuItem | swCommandItemType_e.swToolbarItem));

            cmdGroup.HasToolbar = true;
            cmdGroup.HasMenu = true;
            cmdGroup.Activate();
        }
        public void RemoveCommandMgr()
        {
            iCmdMgr.RemoveCommandGroup(1);
        }
        #endregion Command Manager

        #region PMP
        public void RemovePMP()
        {
            myPMP = null;
        }
        public void _cbCreatePMP()
        {
            myPMP = new PMPInfo((SldWorks.SldWorks)iSwApp);
            myPMP.ActiveModel = (ModelDoc2)iSwApp.ActiveDoc;
        }
        #endregion PMP

        #region Event Hooks
        private void AddEventHooks()
        {
            iSwApp.ActiveModelDocChangeNotify += new DSldWorksEvents_ActiveModelDocChangeNotifyEventHandler(iSwApp_ActiveModelDocChangeNotify);
        }
        private void RemoveEventHooks()
        {
            iSwApp.ActiveModelDocChangeNotify -= new DSldWorksEvents_ActiveModelDocChangeNotifyEventHandler(iSwApp_ActiveModelDocChangeNotify);
        }

        int iSwApp_ActiveModelDocChangeNotify()
        {
            _cbCreatePMP();
            return 0;
        }
        #endregion Event Hooks

    }
}
