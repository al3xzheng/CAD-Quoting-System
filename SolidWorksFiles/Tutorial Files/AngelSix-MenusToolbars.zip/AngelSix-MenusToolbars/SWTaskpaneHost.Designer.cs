﻿namespace AngelSix
{
    partial class SWTaskpaneHost
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bAddItems = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.cbShowForParts = new System.Windows.Forms.CheckBox();
            this.cbShowForAssemblies = new System.Windows.Forms.CheckBox();
            this.cbShowForDrawings = new System.Windows.Forms.CheckBox();
            this.bSetImageFile = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Menus && Toolbars";
            // 
            // bAddItems
            // 
            this.bAddItems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.bAddItems.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bAddItems.Location = new System.Drawing.Point(20, 63);
            this.bAddItems.Name = "bAddItems";
            this.bAddItems.Size = new System.Drawing.Size(270, 24);
            this.bAddItems.TabIndex = 2;
            this.bAddItems.Text = "Add Items";
            this.bAddItems.UseVisualStyleBackColor = true;
            this.bAddItems.Click += new System.EventHandler(this.bAddItems_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(311, 69);
            this.panel1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Location = new System.Drawing.Point(17, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Controlling menus and toolbars dynamically!";
            // 
            // cbShowForParts
            // 
            this.cbShowForParts.AutoSize = true;
            this.cbShowForParts.ForeColor = System.Drawing.Color.White;
            this.cbShowForParts.Location = new System.Drawing.Point(31, 93);
            this.cbShowForParts.Name = "cbShowForParts";
            this.cbShowForParts.Size = new System.Drawing.Size(95, 17);
            this.cbShowForParts.TabIndex = 4;
            this.cbShowForParts.Text = "Show for Parts";
            this.cbShowForParts.UseVisualStyleBackColor = true;
            // 
            // cbShowForAssemblies
            // 
            this.cbShowForAssemblies.AutoSize = true;
            this.cbShowForAssemblies.ForeColor = System.Drawing.Color.White;
            this.cbShowForAssemblies.Location = new System.Drawing.Point(31, 116);
            this.cbShowForAssemblies.Name = "cbShowForAssemblies";
            this.cbShowForAssemblies.Size = new System.Drawing.Size(123, 17);
            this.cbShowForAssemblies.TabIndex = 5;
            this.cbShowForAssemblies.Text = "Show for Assemblies";
            this.cbShowForAssemblies.UseVisualStyleBackColor = true;
            // 
            // cbShowForDrawings
            // 
            this.cbShowForDrawings.AutoSize = true;
            this.cbShowForDrawings.ForeColor = System.Drawing.Color.White;
            this.cbShowForDrawings.Location = new System.Drawing.Point(31, 139);
            this.cbShowForDrawings.Name = "cbShowForDrawings";
            this.cbShowForDrawings.Size = new System.Drawing.Size(115, 17);
            this.cbShowForDrawings.TabIndex = 6;
            this.cbShowForDrawings.Text = "Show for Drawings";
            this.cbShowForDrawings.UseVisualStyleBackColor = true;
            // 
            // bSetImageFile
            // 
            this.bSetImageFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.bSetImageFile.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bSetImageFile.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bSetImageFile.Location = new System.Drawing.Point(20, 162);
            this.bSetImageFile.Name = "bSetImageFile";
            this.bSetImageFile.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.bSetImageFile.Size = new System.Drawing.Size(270, 34);
            this.bSetImageFile.TabIndex = 7;
            this.bSetImageFile.Text = "Set Image File...";
            this.bSetImageFile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bSetImageFile.UseVisualStyleBackColor = true;
            this.bSetImageFile.Click += new System.EventHandler(this.bSetImageFile_Click);
            // 
            // SWTaskpaneHost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.bSetImageFile);
            this.Controls.Add(this.cbShowForDrawings);
            this.Controls.Add(this.cbShowForAssemblies);
            this.Controls.Add(this.cbShowForParts);
            this.Controls.Add(this.bAddItems);
            this.Controls.Add(this.panel1);
            this.Name = "SWTaskpaneHost";
            this.Size = new System.Drawing.Size(311, 452);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bAddItems;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cbShowForParts;
        private System.Windows.Forms.CheckBox cbShowForAssemblies;
        private System.Windows.Forms.CheckBox cbShowForDrawings;
        private System.Windows.Forms.Button bSetImageFile;
    }
}
