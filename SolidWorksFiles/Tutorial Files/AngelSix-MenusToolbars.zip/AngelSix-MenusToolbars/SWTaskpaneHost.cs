﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swcommands;
using SolidWorks.Interop.swconst;
using SolidWorks.Interop.swpublished;
using SolidWorksTools;
using System.Runtime.InteropServices;

namespace AngelSix
{
    [ComVisible(true)]
    [ProgId(SWTASKPANE_PROGID)]
    public partial class SWTaskpaneHost : UserControl
    {
        #region Private Members
        public const string SWTASKPANE_PROGID = "AngelSix.SWTaskPane_MenusAndToolbars";
        private SldWorks mSWApplication;
        private int mCookie;
        private CommandManager mCommandManager;
        private bool mCommandItemsAdded;
        private CommandGroup mCommandGroup;
        private int mCommandGroupId = 1;
        private string imageLocation;
        #endregion

        #region .ctor
        public SWTaskpaneHost()
        {
            InitializeComponent();
        }
        #endregion

        #region Init
        public void Connect(SldWorks swApp, int cookie)
        {
            // Store the SolidWorks instance passed in
            mSWApplication = swApp;
            mCookie = cookie;

            // One-time get the command manager for our add-in
            mCommandManager = mSWApplication.GetCommandManager(mCookie);
        }
        #endregion

        #region Form Event Handlers
        private void bAddItems_Click(object sender, EventArgs e)
        {
            // Have we added items yet?
            if (mCommandItemsAdded)
            {
                // Yes, so this click is to remove them
                RemoveCommandItems();
                // Update the text and variable
                bAddItems.Text = "Add Items";
                mCommandItemsAdded = false;
            }
            else
            {
                // No, so this click is to add them
                AddCommandItems();

                // Update the text and variable
                bAddItems.Text = "Remove Items";
                mCommandItemsAdded = true;
            }
        }

        private void bSetImageFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Bitmap (*.bmp) | *.bmp";
                ofd.Title = "Select menu image file";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = ofd.FileName;
                    bSetImageFile.Image = Image.FromFile(imageLocation);
                }
            }
        }
        #endregion

        private void AddCommandItems()
        {
            // Show when nothing is displayed by default
            int docDisplay = (int)swDocTemplateTypes_e.swDocTemplateTypeNONE;
            // If selected, show for parts
            if (cbShowForParts.Checked)
                docDisplay |= (int)swDocTemplateTypes_e.swDocTemplateTypePART;
            // If selected, show for assemblies
            if (cbShowForAssemblies.Checked)
                docDisplay |= (int)swDocTemplateTypes_e.swDocTemplateTypeASSEMBLY;
            // If selected, show for drawings
            if (cbShowForDrawings.Checked)
                docDisplay |= (int)swDocTemplateTypes_e.swDocTemplateTypeDRAWING;

            // Add the items
            AddCommandItems(docDisplay, imageLocation);
        }

        private void AddCommandItems(int documentTypes, string imageFile)
        {
            // Create a new command group which is the main menu item, and the toolbar title
            mCommandGroup = mCommandManager.CreateCommandGroup(mCommandGroupId, "Convert", "", "", -1);

            // Set the group to have both a menu and a toolbar
            // You could easily add new parameters and UI items to allow
            // the user to dynamically alter these settings
            mCommandGroup.HasMenu = true;
            mCommandGroup.HasToolbar = true;
            mCommandGroup.ShowInDocumentType = documentTypes;
            mCommandGroup.SmallIconList = mCommandGroup.SmallMainIcon = imageFile;
            mCommandGroup.LargeIconList = mCommandGroup.LargeMainIcon = imageFile;

            // We want all command items to be a menu and toolbar item
            int itemType = (int)(swCommandItemType_e.swMenuItem | swCommandItemType_e.swToolbarItem);

            mCommandGroup.AddCommandItem2("PDF", 0, "", "Save model as PDF", 0, "PDFItemClicked", "PDFEnable", 1001, itemType);
            mCommandGroup.AddCommandItem2("JPEG", 1, "", "Save model as JPEG", 1, "JPEGItemClicked", "JPEGEnable", 1002, itemType);
            mCommandGroup.AddCommandItem2("DXF", 2, "", "Save model as DXF", 2, "DXFItemClicked", "DXFEnable", 1003, itemType);

            mCommandGroup.Activate();
        }

        private void RemoveCommandItems()
        {
            mCommandManager.RemoveCommandGroup(mCommandGroupId);
        }
    }
}