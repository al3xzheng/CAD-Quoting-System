﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swcommands;
using SolidWorks.Interop.swconst;
using SolidWorks.Interop.swpublished;
using SolidWorksTools;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace AngelSix
{
    public class SWIntegration : ISwAddin
    {
        #region Private Members
        public SldWorks mSWApplication;
        private int mSWCookie;
        private TaskpaneView mTaskpaneView;
        private SWTaskpaneHost mTaskpaneHost;

        #endregion

        #region SW Connection

        public bool ConnectToSW(object ThisSW, int Cookie)
        {
            mSWApplication = (SldWorks)ThisSW;
            mSWCookie = Cookie;

            // Set-up add-in call back info
            bool result = mSWApplication.SetAddinCallbackInfo(0, this, Cookie);

            this.UISetup();

            return true; 
        }

        public bool DisconnectFromSW()
        {
            this.UITeardown();
            return true;
        }

        #endregion

        #region COM Register

        [ComRegisterFunction()]
        private static void ComRegister(Type t)
        {
            string keyPath = String.Format(@"SOFTWARE\SolidWorks\AddIns\{0:b}", t.GUID);

            using (Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(keyPath))
            {
                rk.SetValue(null, 1); // Load at startup
                rk.SetValue("Title", "Menus & Toolbars"); // Title
                rk.SetValue("Description", ""); // Description
            }
        }

        [ComUnregisterFunction()]
        private static void ComUnregister(Type t)
        {
            string keyPath = String.Format(@"SOFTWARE\SolidWorks\AddIns\{0:b}", t.GUID);
            Microsoft.Win32.Registry.LocalMachine.DeleteSubKeyTree(keyPath);
        }

        #endregion

        #region UI Setup

        private void UISetup()
        {
            mTaskpaneView = mSWApplication.CreateTaskpaneView2(string.Empty, "Menus and Toolbars");
            mTaskpaneHost = (SWTaskpaneHost)mTaskpaneView.AddControl(SWTaskpaneHost.SWTASKPANE_PROGID, "");
            mTaskpaneHost.Connect(mSWApplication, mSWCookie);
        }

        private void UITeardown()
        {
            mTaskpaneHost = null;
            mTaskpaneView.DeleteView();
            Marshal.ReleaseComObject(mTaskpaneView);
            mTaskpaneView = null;
        }

        #endregion

        #region Menu Functions

        public void PDFItemClicked()
        {
            MessageBox.Show("PDF");
        }
        public void JPEGItemClicked()
        {
            MessageBox.Show("JPEG");
        }
        public void DXFItemClicked()
        {
            MessageBox.Show("DXF");
        }

        public int PDFEnable()
        {
            // Let's disable PDF
            return 0;
        }
        public int JPEGEnable()
        {
            // Let's leave JPEG as default
            return 1;
        }
        public int DXFEnable()
        {
            // Let's hide DXF all together (Doesn't work)
            // SolidWorks doesn't disable or hide it and it
            // also acts odd when different models are open
            // so I wouldn't use this if I were you, stick to
            // 0 and 1 which actually work.
            return 4;
        }

        #endregion
    }
}
