﻿Imports SolidWorks.Interop.sldworks
Imports System.Runtime.InteropServices
Imports SolidWorks.Interop.swpublished

Namespace AngelSix_SwAddin

    Public Class SwIntegration
        Implements SwAddin

        Dim mSWApplication As SldWorks
        Private mSWCookie As Integer
        Private mTaskpaneView As TaskpaneView
        Private mTaskpaneHost As SWTaskpaneHost

        Public Function ConnectToSW(ByVal ThisSW As Object, ByVal Cookie As Integer) As Boolean Implements SwAddin.ConnectToSW

            mSWApplication = DirectCast(ThisSW, SldWorks)
            mSWCookie = Cookie

            ' Set-up add-in call back info
            Dim result = mSWApplication.SetAddinCallbackInfo(0, Me, Cookie)

            Me.UISetup()

            Return True
        End Function

        Public Function DisconnectFromSW() As Boolean Implements SwAddin.DisconnectFromSW
            Me.UITeardown()
            Return True
        End Function

        <ComRegisterFunction()> _
        Private Shared Sub ComRegister(ByVal t As Type)

            Dim keyPath = String.Format("SOFTWARE\SolidWorks\AddIns\{0:b}", t.GUID)

            Using rk As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(keyPath)
                rk.SetValue(Nothing, 1) ' Load at startup
                rk.SetValue("Title", "My SwAddin") ' Title
                rk.SetValue("Description", "All your pixels are belong to us") ' Description
            End Using
        End Sub

        <ComUnregisterFunction()> _
        Private Shared Sub ComUnregister(ByVal t As Type)
            Dim keyPath = String.Format("SOFTWARE\SolidWorks\AddIns\{0:b}", t.GUID)
            Microsoft.Win32.Registry.LocalMachine.DeleteSubKeyTree(keyPath)
        End Sub

        Private Sub UISetup()
            mTaskpaneView = mSWApplication.CreateTaskpaneView2(String.Empty, "Woo! My first SwAddin")
            mTaskpaneHost = DirectCast(mTaskpaneView.AddControl(SWTaskpaneHost.SWTASKPANE_PROGID, ""), SWTaskpaneHost)
        End Sub

        Private Sub UITeardown()
            mTaskpaneHost = Nothing
            mTaskpaneView.DeleteView()
            Marshal.ReleaseComObject(mTaskpaneView)
            mTaskpaneView = Nothing
        End Sub

    End Class

End Namespace