﻿Imports System.Runtime.InteropServices

<ComVisible(True)> _
<ProgId(SWTaskpaneHost.SWTASKPANE_PROGID)> _
Public Class SWTaskpaneHost
    Public Const SWTASKPANE_PROGID = "AngelSix.SWTaskPane_SwAddin"
End Class
